import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  // Clear existing data
  await prisma.activity.deleteMany();
  await prisma.deal.deleteMany();
  await prisma.contact.deleteMany();
  await prisma.company.deleteMany();
  await prisma.user.deleteMany();

  // Create Users
  const eugene = await prisma.user.create({
    data: { name: 'Eugene', email: 'eugene@heferon.tech', role: 'OWNER', market: 'ALL' }
  });
  const miquel = await prisma.user.create({
    data: { name: 'Miquel', email: 'miquel@heferon.tech', role: 'BD_SA', market: 'SA' }
  });
  const conrad = await prisma.user.create({
    data: { name: 'Conrad', email: 'conrad@heferon.tech', role: 'BD_UK_US', market: 'UK' }
  });

  // Create Companies
  const company1 = await prisma.company.create({
    data: { name: 'TechCorp SA', market: 'SA', currency: 'ZAR', industry: 'Software' }
  });
  const company2 = await prisma.company.create({
    data: { name: 'London Finance', market: 'UK', currency: 'GBP', industry: 'Finance' }
  });

  // Create Contacts
  const contact1 = await prisma.contact.create({
    data: { firstName: 'John', lastName: 'Doe', email: 'john@techcorp.co.za', companyId: company1.id, market: 'SA', leadSource: 'LINKEDIN' }
  });
  const contact2 = await prisma.contact.create({
    data: { firstName: 'Jane', lastName: 'Smith', email: 'jane@londonfinance.co.uk', companyId: company2.id, market: 'UK', leadSource: 'INBOUND' }
  });

  // Create Deals
  await prisma.deal.create({
    data: {
      title: 'TechCorp Diagnostic',
      stage: 'DISCOVERY',
      market: 'SA',
      currency: 'ZAR',
      value: 18500,
      dealType: 'DIAGNOSTIC',
      companyId: company1.id,
      contactId: contact1.id,
      assignedToId: miquel.id,
      source: 'LINKEDIN',
      lastActivityAt: new Date()
    }
  });

  await prisma.deal.create({
    data: {
      title: 'London Finance Custom Implementation',
      stage: 'PROPOSAL',
      market: 'UK',
      currency: 'GBP',
      value: 15000,
      dealType: 'CUSTOM',
      companyId: company2.id,
      contactId: contact2.id,
      assignedToId: conrad.id,
      source: 'INBOUND',
      lastActivityAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000) // 8 days ago (stale)
    }
  });

  console.log('Seeded successfully');
}

main().catch(console.error).finally(() => prisma.$disconnect());
