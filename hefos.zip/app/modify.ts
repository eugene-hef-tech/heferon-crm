import fs from 'fs';
import path from 'path';

function run() {
  const dealsPath = path.join(process.cwd(), 'app/deals/page.tsx');
  let content = fs.readFileSync(dealsPath, 'utf8');

  // Colors
  content = content.replace(/#161B3D/g, '#0A0A0A'); // Modals and card bg
  content = content.replace(/#8F9BB3/g, 'zinc-400'); // Muted text
  content = content.replace(/#4ECDE4/g, 'white'); // Primary accent
  content = content.replace(/from-\[#4ECDE4\] to-\[#6853DB\]/g, 'from-white to-zinc-500'); // Gradients
  content = content.replace(/bg-\[#161B3D\]/g, 'bg-[#0A0A0A]');

  // Typography - add Inter & JetBrains
  content = content.replace(/text-\[12px\]/g, 'text-[11px] font-mono tracking-widest'); // Column headers
  content = content.replace(/text-\[13px\]/g, 'text-[13px] font-sans'); 
  content = content.replace(/font-semibold text-white text-\[13px\]/g, 'font-medium font-mono text-white text-[13px]');
  
  // Clean Kanban Column
  content = content.replace(/bg-white\/5 rounded-2xl p-4 min-w-\[280px\] flex-1 flex flex-col border border-white\/5/g, 'bg-[#0A0A0A] rounded-2xl p-4 min-w-[280px] flex-1 flex flex-col border border-white/5 shadow-2xl');
  content = content.replace(/text-\[10px\] px-2 py-0.5 rounded-full border border-white\/5/g, 'font-mono text-[10px] px-2 py-0.5 rounded border border-white/5');

  // Deal Cards - increase padding, dark matte fill
  content = content.replace(/p-4 rounded-xl border border-white\/5 mb-3/g, 'p-5 rounded-xl border border-white/5 mb-3 shadow-lg bg-[#141414] hover:bg-[#1a1a1a]');

  fs.writeFileSync(dealsPath, content);
  
  const files = [
    'app/companies/page.tsx',
    'app/contacts/page.tsx', 
    'app/activities/page.tsx',
    'app/settings/custom-fields/page.tsx',
    'app/settings/automations/page.tsx'
  ];
  
  for (const f of files) {
    const p = path.join(process.cwd(), f);
    if (fs.existsSync(p)) {
      let content = fs.readFileSync(p, 'utf8');
      content = content.replace(/#161B3D/g, '#0A0A0A');
      content = content.replace(/bg-\[#0C0F26\]/g, 'bg-[#050505]');
      content = content.replace(/#8F9BB3/g, 'zinc-400');
      content = content.replace(/text-\[#8F9BB3\]/g, 'text-zinc-400');
      content = content.replace(/#4ECDE4/g, 'white');
      content = content.replace(/from-\[#4ECDE4\] to-\[#6853DB\]/g, 'from-white to-zinc-500');
      fs.writeFileSync(p, content);
    }
  }
  
  console.log('Styles updated.');
}

run();
