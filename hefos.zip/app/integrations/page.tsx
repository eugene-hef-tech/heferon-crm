export default function IntegrationsPage() {
  return (
    <div className="space-y-6 h-full flex flex-col">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Developer resources</h1>
      </div>

      <div className="flex gap-6 border-b border-white/5 pb-4">
        <button className="text-[zinc-400] hover:text-white transition-colors pb-1">Common use cases</button>
        <button className="text-white border-b-2 border-[white] pb-1 font-medium">Integrations</button>
        <button className="text-[zinc-400] hover:text-white transition-colors pb-1">Statistics</button>
        <button className="text-[zinc-400] hover:text-white transition-colors pb-1">Documentation ▾</button>
        <button className="text-[zinc-400] hover:text-white transition-colors pb-1">More ▾</button>
      </div>

      <div className="flex-1 bg-[#0A0A0A] rounded-2xl border border-white/5 overflow-hidden flex flex-col">
        <div className="p-4 border-b border-white/5 flex gap-4">
          <div className="relative flex-1 max-w-md">
            <input 
              type="text" 
              placeholder="Filter and search" 
              className="w-full pl-4 pr-10 py-2 bg-white/5 border border-white/10 rounded-lg focus:outline-none focus:ring-1 focus:ring-[white] focus:border-transparent text-white placeholder-[zinc-400] text-[13px]"
            />
            <svg className="absolute right-3 top-1/2 -translate-y-1/2 text-[zinc-400]" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-[13px] border-collapse">
            <thead>
              <tr className="border-b border-white/5">
                <th className="p-4 font-medium text-[zinc-400] w-10">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
                </th>
                <th className="p-4 font-medium text-[zinc-400]">ID</th>
                <th className="p-4 font-medium text-[zinc-400]">User</th>
                <th className="p-4 font-medium text-[zinc-400]">Name</th>
                <th className="p-4 font-medium text-[zinc-400]">Scope</th>
                <th className="p-4 font-medium text-[zinc-400]">Events</th>
                <th className="p-4 font-medium text-[zinc-400]">Widgets</th>
              </tr>
            </thead>
          </table>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center p-12">
          <div className="w-24 h-24 mb-4 opacity-20">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" className="w-full h-full text-white">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
              <polyline points="14 2 14 8 20 8"></polyline>
              <line x1="9" y1="15" x2="15" y2="9"></line>
              <line x1="9" y1="9" x2="15" y2="15"></line>
            </svg>
          </div>
          <p className="text-[zinc-400] text-xl font-light">- No data -</p>
        </div>
      </div>
    </div>
  );
}
