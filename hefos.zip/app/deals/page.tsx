'use client';

import { useState, useEffect } from 'react';
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors, DragEndEvent, DragOverEvent } from '@dnd-kit/core';
import { SortableContext, arrayMove, sortableKeyboardCoordinates, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { useDroppable } from '@dnd-kit/core';

import { getCurrentUser, hasPermission } from '@/lib/auth';

const STAGES = ['LEAD_CAPTURE', 'MQL', 'SQL', 'DISCOVERY', 'PROPOSAL', 'NEGOTIATION', 'CLOSED_WON', 'CLOSED_LOST'];

function DealModal({ deal, onClose, onUpdate, userRole }: { deal: any, onClose: () => void, onUpdate: (deal: any) => void, userRole: string }) {
  const [notes, setNotes] = useState(deal.notes || '');
  const [saving, setSaving] = useState(false);
  const canEdit = hasPermission(userRole, 'SALES_REP');

  const handleSaveNotes = async () => {
    if (!canEdit) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/deals/${deal.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ notes })
      });
      if (res.ok) {
        const updatedDeal = await res.json();
        onUpdate(updatedDeal);
      }
    } catch (error) {
      console.error('Failed to save notes', error);
    } finally {
      setSaving(false);
    }
  };

  const getHealthColor = (lastActivityAt: string | null) => {
    if (!lastActivityAt) return 'bg-white/10';
    const days = (new Date().getTime() - new Date(lastActivityAt).getTime()) / (1000 * 3600 * 24);
    if (days > 7) return 'bg-[#FF3D71]';
    if (days > 3) return 'bg-[#FFAB00]';
    return 'bg-[#00E096]';
  };

  const getHealthText = (lastActivityAt: string | null) => {
    if (!lastActivityAt) return 'No Activity';
    const days = (new Date().getTime() - new Date(lastActivityAt).getTime()) / (1000 * 3600 * 24);
    if (days > 7) return 'Stale';
    if (days > 3) return 'Caution';
    return 'Healthy';
  };

  const stageIndex = STAGES.indexOf(deal.stage);
  const progressPercentage = ((stageIndex + 1) / STAGES.length) * 100;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-[#0A0A0A] rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto border border-white/10 shadow-2xl" onClick={e => e.stopPropagation()}>
        <div className="p-6 border-b border-white/10 flex justify-between items-center sticky top-0 bg-[#0A0A0A] z-10">
          <div className="flex items-center gap-4">
            <h2 className="text-xl font-bold text-white">{deal.title}</h2>
            <div className="flex items-center gap-2 bg-white/5 px-3 py-1 rounded-full border border-white/10">
              <div className={`w-2 h-2 rounded-full ${getHealthColor(deal.lastActivityAt)}`} />
              <span className="text-xs font-medium text-white">{getHealthText(deal.lastActivityAt)}</span>
            </div>
          </div>
          <button onClick={onClose} className="text-[zinc-400] hover:text-white text-2xl">&times;</button>
        </div>
        <div className="p-6 space-y-6">
          
          {/* Progress Bar */}
          <div>
            <div className="flex justify-between text-xs text-[zinc-400] mb-2">
              <span>Stage Progress</span>
              <span className="font-medium text-white">{deal.stage.replace('_', ' ')} ({Math.round(progressPercentage)}%)</span>
            </div>
            <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-[white] to-[#6853DB] transition-all duration-500"
                style={{ width: `${progressPercentage}%` }}
              />
            </div>
            <div className="flex justify-between mt-2">
              {STAGES.map((stage, idx) => (
                <div key={stage} className={`text-[10px] ${idx <= stageIndex ? 'text-[white]' : 'text-[zinc-400]/50'}`}>
                  {idx === 0 || idx === STAGES.length - 1 || idx === stageIndex ? stage.replace('_', ' ') : '•'}
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div>
              <h3 className="text-sm font-semibold text-[zinc-400] uppercase tracking-wider mb-3">Company Info</h3>
              <div className="bg-white/5 p-4 rounded-xl border border-white/5 space-y-2">
                <p className="text-white"><span className="text-[zinc-400] text-xs">Name:</span> {deal.company?.name || 'N/A'}</p>
                <p className="text-white"><span className="text-[zinc-400] text-xs">Industry:</span> {deal.company?.industry || 'N/A'}</p>
                <p className="text-white"><span className="text-[zinc-400] text-xs">Website:</span> {deal.company?.website || 'N/A'}</p>
              </div>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-[zinc-400] uppercase tracking-wider mb-3">Contact Info</h3>
              <div className="bg-white/5 p-4 rounded-xl border border-white/5 space-y-2">
                <p className="text-white"><span className="text-[zinc-400] text-xs">Name:</span> {deal.contact?.firstName} {deal.contact?.lastName}</p>
                <p className="text-white"><span className="text-[zinc-400] text-xs">Email:</span> {deal.contact?.email || 'N/A'}</p>
                <p className="text-white"><span className="text-[zinc-400] text-xs">Phone:</span> {deal.contact?.phone || 'N/A'}</p>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-[zinc-400] uppercase tracking-wider mb-3">Notes</h3>
            <div className="space-y-3">
              <textarea 
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                disabled={!canEdit}
                className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-white text-sm min-h-[100px] focus:outline-none focus:border-[white] disabled:opacity-50"
                placeholder={canEdit ? "Add notes here..." : "No notes available."}
              />
              {canEdit && (
                <button 
                  onClick={handleSaveNotes}
                  disabled={saving || notes === (deal.notes || '')}
                  className="bg-[white] text-[#0A0A0A] px-4 py-2 rounded-lg text-sm font-semibold disabled:opacity-50 transition-opacity"
                >
                  {saving ? 'Saving...' : 'Save Notes'}
                </button>
              )}
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-[zinc-400] uppercase tracking-wider mb-3">Activity Log</h3>
            <div className="bg-white/5 rounded-xl border border-white/5 overflow-hidden">
              {deal.activities && deal.activities.length > 0 ? (
                <div className="divide-y divide-white/5">
                  {deal.activities.map((activity: any) => (
                    <div key={activity.id} className="p-4">
                      <div className="flex justify-between items-start mb-1">
                        <span className="text-sm font-medium text-white">{activity.subject}</span>
                        <span className="text-xs text-[zinc-400]">{new Date(activity.createdAt).toLocaleDateString()}</span>
                      </div>
                      <p className="text-xs text-[zinc-400]">{activity.type} • {activity.direction}</p>
                      {activity.description && <p className="text-sm text-white/80 mt-2">{activity.description}</p>}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-4 text-sm text-[zinc-400] text-center">No activities recorded yet.</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function NewDealModal({ onClose, onAdd }: { onClose: () => void, onAdd: (deal: any) => void }) {
  const [formData, setFormData] = useState({
    title: '',
    stage: 'LEAD_CAPTURE',
    market: 'SA',
    currency: 'ZAR',
    value: '',
    dealType: 'CUSTOM',
    companyName: '',
    contactFirstName: '',
    contactLastName: '',
    contactEmail: ''
  });
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch('/api/deals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          value: Number(formData.value)
        })
      });
      if (res.ok) {
        const newDeal = await res.json();
        onAdd(newDeal);
      } else {
        console.error('Failed to create deal');
      }
    } catch (error) {
      console.error('Error creating deal', error);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-[#0A0A0A] rounded-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto border border-white/10 shadow-2xl" onClick={e => e.stopPropagation()}>
        <div className="p-6 border-b border-white/10 flex justify-between items-center sticky top-0 bg-[#0A0A0A] z-10">
          <h2 className="text-xl font-bold text-white">New Deal</h2>
          <button onClick={onClose} className="text-[zinc-400] hover:text-white text-2xl">&times;</button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-xs text-[zinc-400] mb-1">Deal Title</label>
            <input required type="text" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-lg p-2.5 text-white text-sm focus:outline-none focus:border-[white]" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-[zinc-400] mb-1">Value</label>
              <input required type="number" min="0" step="0.01" value={formData.value} onChange={e => setFormData({...formData, value: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-lg p-2.5 text-white text-sm focus:outline-none focus:border-[white]" />
            </div>
            <div>
              <label className="block text-xs text-[zinc-400] mb-1">Currency</label>
              <select value={formData.currency} onChange={e => setFormData({...formData, currency: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-lg p-2.5 text-white text-sm focus:outline-none focus:border-[white]">
                <option value="ZAR">ZAR</option>
                <option value="GBP">GBP</option>
                <option value="USD">USD</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-[zinc-400] mb-1">Stage</label>
              <select value={formData.stage} onChange={e => setFormData({...formData, stage: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-lg p-2.5 text-white text-sm focus:outline-none focus:border-[white]">
                {STAGES.map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs text-[zinc-400] mb-1">Market</label>
              <select value={formData.market} onChange={e => setFormData({...formData, market: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-lg p-2.5 text-white text-sm focus:outline-none focus:border-[white]">
                <option value="SA">South Africa</option>
                <option value="UK">United Kingdom</option>
                <option value="US">United States</option>
              </select>
            </div>
          </div>
          
          <div className="pt-4 border-t border-white/5">
            <h3 className="text-sm font-semibold text-white mb-3">Company & Contact</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-xs text-[zinc-400] mb-1">Company Name</label>
                <input required type="text" value={formData.companyName} onChange={e => setFormData({...formData, companyName: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-lg p-2.5 text-white text-sm focus:outline-none focus:border-[white]" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-[zinc-400] mb-1">Contact First Name</label>
                  <input required type="text" value={formData.contactFirstName} onChange={e => setFormData({...formData, contactFirstName: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-lg p-2.5 text-white text-sm focus:outline-none focus:border-[white]" />
                </div>
                <div>
                  <label className="block text-xs text-[zinc-400] mb-1">Contact Last Name</label>
                  <input required type="text" value={formData.contactLastName} onChange={e => setFormData({...formData, contactLastName: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-lg p-2.5 text-white text-sm focus:outline-none focus:border-[white]" />
                </div>
              </div>
              <div>
                <label className="block text-xs text-[zinc-400] mb-1">Contact Email</label>
                <input required type="email" value={formData.contactEmail} onChange={e => setFormData({...formData, contactEmail: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-lg p-2.5 text-white text-sm focus:outline-none focus:border-[white]" />
              </div>
            </div>
          </div>

          <div className="pt-6 flex justify-end gap-3">
            <button type="button" onClick={onClose} className="px-4 py-2 rounded-lg text-sm font-semibold text-[zinc-400] hover:text-white transition-colors">Cancel</button>
            <button type="submit" disabled={saving} className="bg-[white] text-[#0A0A0A] px-6 py-2 rounded-lg text-sm font-semibold disabled:opacity-50 transition-opacity">
              {saving ? 'Creating...' : 'Create Deal'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function SortableDealCard({ deal, onClick }: { deal: any, onClick: () => void }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: deal.id, data: { type: 'Deal', deal } });
  const style = { transform: CSS.Transform.toString(transform), transition, opacity: isDragging ? 0.5 : 1 };

  const formatCurrency = (value: number, currency: string) => {
    const symbols: Record<string, string> = { ZAR: 'R', GBP: '£', USD: '$' };
    return `${symbols[currency] || currency}${value.toLocaleString()}`;
  };

  const getHealthColor = (lastActivityAt: string | null) => {
    if (!lastActivityAt) return 'bg-white/10';
    const days = (new Date().getTime() - new Date(lastActivityAt).getTime()) / (1000 * 3600 * 24);
    if (days > 7) return 'bg-[#FF3D71]';
    if (days > 3) return 'bg-[#FFAB00]';
    return 'bg-[#00E096]';
  };

  const getHealthTooltip = (lastActivityAt: string | null) => {
    if (!lastActivityAt) return 'No activity yet';
    const days = Math.floor((new Date().getTime() - new Date(lastActivityAt).getTime()) / (1000 * 3600 * 24));
    return `${days} day${days === 1 ? '' : 's'} since last activity`;
  };

  const getMarketColor = (market: string) => {
    const colors: Record<string, string> = { SA: 'text-[#FFD700]', UK: 'text-[white]', US: 'text-[#6853DB]' };
    return colors[market] || 'text-white';
  };

  return (
    <div ref={setNodeRef} style={style} {...attributes} {...listeners} onClick={onClick} className="bg-[#0A0A0A] p-5 rounded-xl border border-white/5 mb-3 shadow-lg bg-[#141414] hover:bg-[#1a1a1a] cursor-grab active:cursor-grabbing hover:border-white/10 transition-colors">
      <div className="flex justify-between items-start mb-2">
        <h4 className="font-medium text-white text-[13px] font-sans font-sans">{deal.company?.name || 'Unknown Company'}</h4>
        <div className={`w-2 h-2 rounded-full ${getHealthColor(deal.lastActivityAt)}`} title={getHealthTooltip(deal.lastActivityAt)} />
      </div>
      <p className="text-xs text-[zinc-400] mb-3">{deal.contact?.firstName} {deal.contact?.lastName}</p>
      <div className="flex justify-between items-center mt-2 pt-3 border-t border-white/5">
        <span className="font-medium font-mono text-white text-[13px] font-sans font-sans">{formatCurrency(deal.value, deal.currency)}</span>
        <span className={`text-[10px] px-1.5 py-0.5 rounded bg-white/5 font-medium ${getMarketColor(deal.market)}`}>{deal.market}</span>
      </div>
    </div>
  );
}

function KanbanColumn({ title, deals, onDealClick }: { title: string, deals: any[], onDealClick: (deal: any) => void }) {
  const { setNodeRef } = useDroppable({ id: title, data: { type: 'Column', stage: title } });

  return (
    <div className="bg-[#0A0A0A] rounded-2xl p-4 min-w-[280px] flex-1 flex flex-col border border-white/5 shadow-2xl">
      <h3 className="font-semibold text-[zinc-400] text-[11px] font-mono tracking-widest uppercase tracking-[1px] mb-4 flex justify-between items-center">
        {title.replace('_', ' ')}
        <span className="bg-[#0A0A0A] text-white font-mono text-[10px] px-2 py-0.5 rounded border border-white/5">{deals.length}</span>
      </h3>
      <div ref={setNodeRef} className="flex-1 min-h-[200px]">
        <SortableContext items={deals.map(d => d.id)} strategy={verticalListSortingStrategy}>
          {deals.map(deal => (
            <SortableDealCard key={deal.id} deal={deal} onClick={() => onDealClick(deal)} />
          ))}
        </SortableContext>
      </div>
    </div>
  );
}

export default function DealsPage() {
  const [deals, setDeals] = useState<any[]>([]);
  const [marketFilter, setMarketFilter] = useState('ALL');
  const [loading, setLoading] = useState(true);
  const [selectedDeal, setSelectedDeal] = useState<any | null>(null);
  const [isNewDealModalOpen, setIsNewDealModalOpen] = useState(false);
  const user = getCurrentUser();
  const canCreate = hasPermission(user.role, 'SALES_REP');

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  useEffect(() => {
    fetchDeals();
  }, []);

  const fetchDeals = async () => {
    try {
      const res = await fetch('/api/deals');
      const data = await res.json();
      setDeals(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleDragOver = (event: DragOverEvent) => {
    if (!hasPermission(user.role, 'SALES_REP')) return;
    const { active, over } = event;
    if (!over) return;

    const activeId = active.id;
    const overId = over.id;

    if (activeId === overId) return;

    const isActiveDeal = active.data.current?.type === 'Deal';
    const isOverColumn = over.data.current?.type === 'Column';
    const isOverDeal = over.data.current?.type === 'Deal';

    if (!isActiveDeal) return;

    if (isOverColumn || isOverDeal) {
      const targetStage = isOverColumn ? over.data.current?.stage : over.data.current?.deal.stage;
      
      setDeals((prev) => {
        const activeIndex = prev.findIndex((d) => d.id === activeId);
        if (prev[activeIndex].stage !== targetStage) {
          const newDeals = [...prev];
          newDeals[activeIndex] = { ...newDeals[activeIndex], stage: targetStage };
          return newDeals;
        }
        return prev;
      });
    }
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    if (!hasPermission(user.role, 'SALES_REP')) return;
    const { active, over } = event;
    if (!over) return;

    const activeDeal = deals.find(d => d.id === active.id);
    if (!activeDeal) return;

    // Send update to server
    try {
      await fetch(`/api/deals/${activeDeal.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stage: activeDeal.stage })
      });
    } catch (error) {
      console.error('Failed to update deal stage', error);
    }
  };

  const handleUpdateDeal = (updatedDeal: any) => {
    setDeals(prev => prev.map(d => d.id === updatedDeal.id ? updatedDeal : d));
    if (selectedDeal?.id === updatedDeal.id) {
      setSelectedDeal(updatedDeal);
    }
  };

  const handleAddDeal = (newDeal: any) => {
    setDeals(prev => [newDeal, ...prev]);
    setIsNewDealModalOpen(false);
  };

  const [search, setSearch] = useState('');
  const [assignedToFilter, setAssignedToFilter] = useState('ALL');
  const [minValFilter, setMinValFilter] = useState('');
  const [maxValFilter, setMaxValFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState('ALL');

  const safeDeals = Array.isArray(deals) ? deals : [];
  const assignedUsers = Array.from(new Set(safeDeals.map(d => d.assignedTo?.name).filter(Boolean)));

  const filteredDeals = safeDeals.filter(d => {
    const matchesMarket = marketFilter === 'ALL' || d.market === marketFilter;
    const matchesSearch = d.title.toLowerCase().includes(search.toLowerCase()) ||
      d.company?.name?.toLowerCase().includes(search.toLowerCase()) ||
      d.contact?.firstName?.toLowerCase().includes(search.toLowerCase()) ||
      d.contact?.lastName?.toLowerCase().includes(search.toLowerCase());
    const matchesAssigned = assignedToFilter === 'ALL' || d.assignedTo?.name === assignedToFilter;
    const matchesType = typeFilter === 'ALL' || d.dealType === typeFilter;
    
    const dealValue = Number(d.value);
    const matchesMinVal = minValFilter === '' || dealValue >= Number(minValFilter);
    const matchesMaxVal = maxValFilter === '' || dealValue <= Number(maxValFilter);

    return matchesMarket && matchesSearch && matchesAssigned && matchesType && matchesMinVal && matchesMaxVal;
  });

  const handleExportCSV = () => {
    if (!filteredDeals.length) return;
    const headers = ['ID', 'Title', 'Stage', 'Market', 'Currency', 'Value', 'Type', 'Company', 'Contact', 'Assigned To', 'Created At'];
    const csvContent = [
      headers.join(','),
      ...filteredDeals.map(d => [
        d.id,
        `"${d.title.replace(/"/g, '""')}"`,
        d.stage,
        d.market,
        d.currency,
        d.value,
        d.dealType,
        `"${d.company?.name?.replace(/"/g, '""') || ''}"`,
        `"${d.contact?.firstName || ''} ${d.contact?.lastName || ''}"`,
        `"${d.assignedTo?.name || ''}"`,
        d.createdAt
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'deals_export.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) return <div className="text-[zinc-400]">Loading deals...</div>;

  return (
    <div className="h-full flex flex-col">
      <div className="flex flex-col gap-4 mb-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-white">Deals Pipeline</h1>
          <div className="flex items-center gap-4">
            <button 
              onClick={handleExportCSV}
              className="bg-white/10 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-white/20 transition-colors"
            >
              Export CSV
            </button>
            {canCreate && (
              <button 
                onClick={() => setIsNewDealModalOpen(true)}
                className="bg-[white] text-[#0A0A0A] px-4 py-2 rounded-lg text-sm font-semibold hover:bg-opacity-90 transition-colors"
              >
                + New Deal
              </button>
            )}
          </div>
        </div>
        
        <div className="flex flex-wrap items-center gap-4 bg-[#0A0A0A] p-4 rounded-xl border border-white/5">
          <div className="relative flex-1 min-w-[200px]">
            <input 
              type="text" 
              placeholder="Search deals..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-4 pr-4 py-1.5 bg-white/5 border border-white/10 rounded-lg focus:outline-none focus:ring-1 focus:ring-[white] focus:border-transparent text-white placeholder-[zinc-400] text-[13px] font-sans font-sans"
            />
          </div>
          
          <select 
            value={assignedToFilter} 
            onChange={e => setAssignedToFilter(e.target.value)}
            className="bg-white/5 border border-white/10 rounded-lg p-1.5 text-white text-[13px] font-sans font-sans focus:outline-none focus:border-[white]"
          >
            <option value="ALL">All Users</option>
            {assignedUsers.map(user => (
              <option key={user as string} value={user as string}>{user as string}</option>
            ))}
          </select>

          <select 
            value={typeFilter} 
            onChange={e => setTypeFilter(e.target.value)}
            className="bg-white/5 border border-white/10 rounded-lg p-1.5 text-white text-[13px] font-sans font-sans focus:outline-none focus:border-[white]"
          >
            <option value="ALL">All Types</option>
            <option value="DIAGNOSTIC">Diagnostic</option>
            <option value="CUSTOM">Custom</option>
          </select>

          <div className="flex items-center gap-2">
            <input 
              type="number" 
              placeholder="Min Val" 
              value={minValFilter}
              onChange={(e) => setMinValFilter(e.target.value)}
              className="w-24 pl-2 pr-2 py-1.5 bg-white/5 border border-white/10 rounded-lg focus:outline-none focus:ring-1 focus:ring-[white] focus:border-transparent text-white placeholder-[zinc-400] text-[13px] font-sans font-sans"
            />
            <span className="text-[zinc-400]">-</span>
            <input 
              type="number" 
              placeholder="Max Val" 
              value={maxValFilter}
              onChange={(e) => setMaxValFilter(e.target.value)}
              className="w-24 pl-2 pr-2 py-1.5 bg-white/5 border border-white/10 rounded-lg focus:outline-none focus:ring-1 focus:ring-[white] focus:border-transparent text-white placeholder-[zinc-400] text-[13px] font-sans font-sans"
            />
          </div>

          <div className="flex gap-2 bg-white/5 p-1 rounded-lg ml-auto">
            {['ALL', 'SA', 'UK', 'US'].map(m => (
              <button
                key={m}
                onClick={() => setMarketFilter(m)}
                className={`px-4 py-1.5 rounded-md text-[13px] font-sans font-sans font-semibold transition-colors ${marketFilter === m ? 'bg-[#0A0A0A] text-white shadow-sm' : 'text-[zinc-400] hover:text-white'}`}
              >
                {m === 'ALL' ? 'ALL MARKETS' : m === 'SA' ? 'SOUTH AFRICA' : m === 'UK' ? 'UNITED KINGDOM' : 'UNITED STATES'}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-x-auto custom-scrollbar">
        <div className="flex gap-4 pb-4" style={{ width: 'max-content', minHeight: '600px' }}>
          <DndContext sensors={sensors} collisionDetection={closestCenter} onDragOver={handleDragOver} onDragEnd={handleDragEnd}>
            {STAGES.map(stage => (
              <KanbanColumn 
                key={stage} 
                title={stage} 
                deals={filteredDeals.filter(d => d.stage === stage)} 
                onDealClick={setSelectedDeal}
              />
            ))}
          </DndContext>
        </div>
      </div>

      {selectedDeal && (
        <DealModal 
          deal={selectedDeal} 
          onClose={() => setSelectedDeal(null)} 
          onUpdate={handleUpdateDeal}
          userRole={user.role}
        />
      )}

      {isNewDealModalOpen && (
        <NewDealModal 
          onClose={() => setIsNewDealModalOpen(false)} 
          onAdd={handleAddDeal}
        />
      )}
    </div>
  );
}
