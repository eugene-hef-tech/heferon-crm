'use client';

import { useState, useEffect } from 'react';
import { Search, Filter, Plus } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { getCurrentUser } from '@/lib/auth';

export default function ContactsPage() {
  const [contacts, setContacts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({ firstName: '', lastName: '', email: '', phone: '', companyId: '', market: 'SA', leadSource: 'INBOUND' });
  const [saving, setSaving] = useState(false);
  const [companies, setCompanies] = useState<any[]>([]);
  
  const user = getCurrentUser();

  useEffect(() => {
    fetchContacts();
    fetchCompanies();
  }, []);

  const fetchContacts = async () => {
    try {
      const res = await fetch('/api/contacts');
      const data = await res.json();
      setContacts(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCompanies = async () => {
    try {
      const res = await fetch('/api/companies');
      const data = await res.json();
      setCompanies(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error(error);
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch('/api/contacts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...formData, assignedToId: user.id })
      });
      if (res.ok) {
        setIsModalOpen(false);
        setFormData({ firstName: '', lastName: '', email: '', phone: '', companyId: '', market: 'SA', leadSource: 'INBOUND' });
        fetchContacts();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const filteredContacts = contacts.filter(c => 
    `${c.firstName} ${c.lastName}`.toLowerCase().includes(search.toLowerCase()) ||
    c.email.toLowerCase().includes(search.toLowerCase()) ||
    c.company?.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold font-sans tracking-tight text-white">Contacts</h1>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="bg-white text-[#050505] px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-zinc-200 transition-colors border border-transparent text-sm font-semibold"
        >
          <Plus size={16} />
          <span>New Contact</span>
        </button>
      </div>

      <div className="bg-[#0A0A0A] rounded-2xl border border-white/5 overflow-hidden flex flex-col">
        <div className="p-4 border-b border-white/5 flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[zinc-400]" size={18} />
            <input 
              type="text" 
              placeholder="Search contacts..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white/5 border border-white/10 rounded-lg focus:outline-none focus:ring-1 focus:ring-[white] focus:border-transparent text-white placeholder-[zinc-400] text-[13px]"
            />
          </div>
          <button className="px-4 py-2 border border-white/10 rounded-lg flex items-center gap-2 text-[zinc-400] hover:bg-white/5 hover:text-white transition-colors text-[13px] font-medium">
            <Filter size={16} />
            <span>Filter</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-[13px] border-collapse">
            <thead>
              <tr className="border-b border-white/5">
                <th className="p-4 font-medium text-[zinc-400]">Name</th>
                <th className="p-4 font-medium text-[zinc-400]">Company</th>
                <th className="p-4 font-medium text-[zinc-400]">Email</th>
                <th className="p-4 font-medium text-[zinc-400]">Market</th>
                <th className="p-4 font-medium text-[zinc-400]">Status</th>
                <th className="p-4 font-medium text-[zinc-400]">Last Touch</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} className="p-4 text-center text-[zinc-400]">Loading...</td></tr>
              ) : filteredContacts.length === 0 ? (
                <tr><td colSpan={6} className="p-4 text-center text-[zinc-400]">No contacts found.</td></tr>
              ) : (
                filteredContacts.map(contact => (
                  <tr key={contact.id} className="border-b border-white/5 hover:bg-white/5 cursor-pointer transition-colors">
                    <td className="p-4">
                      <div className="font-medium text-white">{contact.firstName} {contact.lastName}</div>
                      <div className="text-xs text-[zinc-400] mt-0.5">{contact.position || '-'}</div>
                    </td>
                    <td className="p-4 text-white">{contact.company?.name || '-'}</td>
                    <td className="p-4 text-[zinc-400]">{contact.email}</td>
                    <td className="p-4">
                      <span className={`text-[10px] px-1.5 py-0.5 rounded bg-white/10 ${contact.market === 'SA' ? 'text-[#FFD700]' : contact.market === 'UK' ? 'text-[white]' : 'text-[#6853DB]'}`}>
                        {contact.market}
                      </span>
                    </td>
                    <td className="p-4">
                      <span className={`text-[10px] px-2 py-1 rounded-full font-medium ${
                        contact.sequenceStatus === 'ACTIVE' ? 'bg-[#00E096]/20 text-[#00E096]' :
                        contact.sequenceStatus === 'REPLIED' ? 'bg-[white]/20 text-[white]' :
                        contact.sequenceStatus === 'OPTED_OUT' ? 'bg-[#FF3D71]/20 text-[#FF3D71]' :
                        'bg-white/10 text-[zinc-400]'
                      }`}>
                        {contact.sequenceStatus.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="p-4 text-[zinc-400]">
                      {contact.lastOutboundTouch ? formatDistanceToNow(new Date(contact.lastOutboundTouch), { addSuffix: true }) : 'Never'}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
          <div className="bg-[#0A0A0A] rounded-2xl w-full max-w-lg border border-white/10 shadow-2xl p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-white tracking-tight">Add Contact</h2>
              <button onClick={() => setIsModalOpen(false)} className="text-zinc-500 hover:text-white">&times;</button>
            </div>
            
            <form onSubmit={handleCreate} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-mono text-zinc-500 uppercase tracking-widest mb-2">First Name</label>
                  <input required type="text" value={formData.firstName} onChange={e => setFormData({...formData, firstName: e.target.value})} className="w-full bg-transparent border-b border-white/20 pb-2 text-white text-sm focus:outline-none focus:border-white transition-colors" />
                </div>
                <div>
                  <label className="block text-[11px] font-mono text-zinc-500 uppercase tracking-widest mb-2">Last Name</label>
                  <input required type="text" value={formData.lastName} onChange={e => setFormData({...formData, lastName: e.target.value})} className="w-full bg-transparent border-b border-white/20 pb-2 text-white text-sm focus:outline-none focus:border-white transition-colors" />
                </div>
              </div>
              <div className="mt-4">
                <label className="block text-[11px] font-mono text-zinc-500 uppercase tracking-widest mb-2">Email Address</label>
                <input required type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="w-full bg-transparent border-b border-white/20 pb-2 text-white text-sm focus:outline-none focus:border-white transition-colors" />
              </div>
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <label className="block text-[11px] font-mono text-zinc-500 uppercase tracking-widest mb-2">Phone</label>
                  <input type="text" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="w-full bg-transparent border-b border-white/20 pb-2 text-white text-sm focus:outline-none focus:border-white transition-colors" />
                </div>
                <div>
                  <label className="block text-[11px] font-mono text-zinc-500 uppercase tracking-widest mb-2">Company</label>
                  <select value={formData.companyId} onChange={e => setFormData({...formData, companyId: e.target.value})} className="w-full bg-[#0A0A0A] border-b border-white/20 pb-2 text-white text-sm focus:outline-none focus:border-white transition-colors">
                    <option value="">No Company</option>
                    {companies.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <label className="block text-[11px] font-mono text-zinc-500 uppercase tracking-widest mb-2">Market</label>
                  <select value={formData.market} onChange={e => setFormData({...formData, market: e.target.value})} className="w-full bg-[#0A0A0A] border-b border-white/20 pb-2 text-white text-sm focus:outline-none focus:border-white transition-colors">
                    <option value="SA">South Africa</option>
                    <option value="UK">United Kingdom</option>
                    <option value="US">United States</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-mono text-zinc-500 uppercase tracking-widest mb-2">Lead Source</label>
                  <select value={formData.leadSource} onChange={e => setFormData({...formData, leadSource: e.target.value})} className="w-full bg-[#0A0A0A] border-b border-white/20 pb-2 text-white text-sm focus:outline-none focus:border-white transition-colors">
                    <option value="INBOUND">Inbound</option>
                    <option value="LINKEDIN">LinkedIn</option>
                    <option value="CLAY">Clay (Outbound)</option>
                    <option value="REFERRAL">Referral</option>
                  </select>
                </div>
              </div>
              
              <div className="pt-6 flex justify-end gap-3 border-t border-white/5 mt-6">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 rounded-lg text-sm font-semibold text-zinc-500 hover:text-white transition-colors">Cancel</button>
                <button type="submit" disabled={saving || !formData.firstName || !formData.email} className="bg-white text-[#050505] px-6 py-2 rounded-lg text-sm font-semibold disabled:opacity-50 transition-opacity">
                  {saving ? 'Saving...' : 'Add Contact'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
