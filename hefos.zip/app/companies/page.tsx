'use client';

import { useState, useEffect } from 'react';
import { Search, Filter, Plus } from 'lucide-react';
import { getCurrentUser } from '@/lib/auth';

export default function CompaniesPage() {
  const [companies, setCompanies] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({ name: '', industry: '', size: '', market: 'SA', website: '', currency: 'ZAR' });
  const [saving, setSaving] = useState(false);
  
  const user = getCurrentUser();

  useEffect(() => {
    fetchCompanies();
  }, []);

  const fetchCompanies = async () => {
    try {
      const res = await fetch('/api/companies');
      const data = await res.json();
      setCompanies(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch('/api/companies', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...formData, assignedToId: user.id })
      });
      if (res.ok) {
        setIsModalOpen(false);
        setFormData({ name: '', industry: '', size: '', market: 'SA', website: '', currency: 'ZAR' });
        fetchCompanies();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const filteredCompanies = companies.filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    (c.industry && c.industry.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold font-sans tracking-tight text-white">Companies</h1>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="bg-white text-[#050505] px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-zinc-200 transition-colors border border-transparent text-sm font-semibold"
        >
          <Plus size={16} />
          <span>New Company</span>
        </button>
      </div>

      <div className="bg-[#0A0A0A] rounded-2xl border border-white/5 overflow-hidden flex flex-col">
        <div className="p-4 border-b border-white/5 flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[zinc-400]" size={18} />
            <input 
              type="text" 
              placeholder="Search companies..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white/5 border border-white/10 rounded-lg focus:outline-none focus:ring-1 focus:ring-[white] focus:border-transparent text-white placeholder-[zinc-400] text-[13px]"
            />
          </div>
          <button className="px-4 py-2 border border-white/10 rounded-lg flex items-center gap-2 text-[zinc-400] hover:bg-white/5 hover:text-white transition-colors text-[13px] font-medium">
            <Filter size={16} />
            <span>Filter</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-[13px] border-collapse">
            <thead>
              <tr className="border-b border-white/5">
                <th className="p-4 font-medium text-[zinc-400]">Company Name</th>
                <th className="p-4 font-medium text-[zinc-400]">Industry</th>
                <th className="p-4 font-medium text-[zinc-400]">Market</th>
                <th className="p-4 font-medium text-[zinc-400]">Contacts</th>
                <th className="p-4 font-medium text-[zinc-400]">Active Deals</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={5} className="p-4 text-center text-[zinc-400]">Loading...</td></tr>
              ) : filteredCompanies.length === 0 ? (
                <tr><td colSpan={5} className="p-4 text-center text-[zinc-400]">No companies found.</td></tr>
              ) : (
                filteredCompanies.map(company => (
                  <tr key={company.id} className="border-b border-white/5 hover:bg-white/5 cursor-pointer transition-colors">
                    <td className="p-4">
                      <div className="font-medium text-white">{company.name}</div>
                      <div className="text-xs text-[white] hover:underline mt-0.5">{company.website}</div>
                    </td>
                    <td className="p-4 text-[zinc-400]">{company.industry || '-'}</td>
                    <td className="p-4">
                      <span className={`text-[10px] px-1.5 py-0.5 rounded bg-white/10 ${company.market === 'SA' ? 'text-[#FFD700]' : company.market === 'UK' ? 'text-[white]' : 'text-[#6853DB]'}`}>
                        {company.market}
                      </span>
                    </td>
                    <td className="p-4 text-[zinc-400]">{company.contacts?.length || 0}</td>
                    <td className="p-4 text-[zinc-400]">{company.deals?.length || 0}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
          <div className="bg-[#0A0A0A] rounded-2xl w-full max-w-lg border border-white/10 shadow-2xl p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-white tracking-tight">Add Company</h2>
              <button onClick={() => setIsModalOpen(false)} className="text-zinc-500 hover:text-white">&times;</button>
            </div>
            
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-[11px] font-mono text-zinc-500 uppercase tracking-widest mb-2">Company Name</label>
                <input required type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full bg-transparent border-b border-white/20 pb-2 text-white text-sm focus:outline-none focus:border-white transition-colors" />
              </div>
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <label className="block text-[11px] font-mono text-zinc-500 uppercase tracking-widest mb-2">Industry</label>
                  <input type="text" value={formData.industry} onChange={e => setFormData({...formData, industry: e.target.value})} className="w-full bg-transparent border-b border-white/20 pb-2 text-white text-sm focus:outline-none focus:border-white transition-colors" />
                </div>
                <div>
                  <label className="block text-[11px] font-mono text-zinc-500 uppercase tracking-widest mb-2">Size</label>
                  <input type="text" value={formData.size} onChange={e => setFormData({...formData, size: e.target.value})} className="w-full bg-transparent border-b border-white/20 pb-2 text-white text-sm focus:outline-none focus:border-white transition-colors" placeholder="e.g. 50-200" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <label className="block text-[11px] font-mono text-zinc-500 uppercase tracking-widest mb-2">Market</label>
                  <select value={formData.market} onChange={e => setFormData({...formData, market: e.target.value})} className="w-full bg-[#0A0A0A] border-b border-white/20 pb-2 text-white text-sm focus:outline-none focus:border-white transition-colors">
                    <option value="SA">South Africa</option>
                    <option value="UK">United Kingdom</option>
                    <option value="US">United States</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-mono text-zinc-500 uppercase tracking-widest mb-2">Currency</label>
                  <select value={formData.currency} onChange={e => setFormData({...formData, currency: e.target.value})} className="w-full bg-[#0A0A0A] border-b border-white/20 pb-2 text-white text-sm focus:outline-none focus:border-white transition-colors">
                    <option value="ZAR">ZAR</option>
                    <option value="GBP">GBP</option>
                    <option value="USD">USD</option>
                  </select>
                </div>
              </div>
              <div className="mt-4">
                <label className="block text-[11px] font-mono text-zinc-500 uppercase tracking-widest mb-2">Website</label>
                <input type="url" value={formData.website} onChange={e => setFormData({...formData, website: e.target.value})} className="w-full bg-transparent border-b border-white/20 pb-2 text-white text-sm focus:outline-none focus:border-white transition-colors" />
              </div>
              
              <div className="pt-6 flex justify-end gap-3 border-t border-white/5 mt-6">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 rounded-lg text-sm font-semibold text-zinc-500 hover:text-white transition-colors">Cancel</button>
                <button type="submit" disabled={saving || !formData.name} className="bg-white text-[#050505] px-6 py-2 rounded-lg text-sm font-semibold disabled:opacity-50 transition-opacity">
                  {saving ? 'Saving...' : 'Add Company'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
