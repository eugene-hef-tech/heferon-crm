'use client';

import { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { formatDistanceToNow } from 'date-fns';

export default function DashboardPage() {
  const [deals, setDeals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDeals();
  }, []);

  const fetchDeals = async () => {
    try {
      const res = await fetch('/api/deals');
      const data = await res.json();
      setDeals(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div>Loading dashboard...</div>;

  const safeDeals = Array.isArray(deals) ? deals : [];
  const zarTotal = safeDeals.filter(d => d.currency === 'ZAR').reduce((acc, d) => acc + Number(d.value), 0);
  const gbpTotal = safeDeals.filter(d => d.currency === 'GBP').reduce((acc, d) => acc + Number(d.value), 0);
  const usdTotal = safeDeals.filter(d => d.currency === 'USD').reduce((acc, d) => acc + Number(d.value), 0);

  const stageProbabilities: Record<string, number> = {
    'LEAD_CAPTURE': 0.05,
    'MQL': 0.10,
    'SQL': 0.20,
    'DISCOVERY': 0.40,
    'PROPOSAL': 0.60,
    'NEGOTIATION': 0.80,
    'CLOSED_WON': 1.00,
    'CLOSED_LOST': 0.00
  };

  const zarForecast = safeDeals.filter(d => d.currency === 'ZAR').reduce((acc, d) => acc + (Number(d.value) * (stageProbabilities[d.stage] || 0)), 0);
  const gbpForecast = safeDeals.filter(d => d.currency === 'GBP').reduce((acc, d) => acc + (Number(d.value) * (stageProbabilities[d.stage] || 0)), 0);
  const usdForecast = safeDeals.filter(d => d.currency === 'USD').reduce((acc, d) => acc + (Number(d.value) * (stageProbabilities[d.stage] || 0)), 0);

  const stages = ['LEAD_CAPTURE', 'MQL', 'SQL', 'DISCOVERY', 'PROPOSAL', 'NEGOTIATION', 'CLOSED_WON', 'CLOSED_LOST'];
  
  const chartData = stages.map(stage => {
    const stageDeals = safeDeals.filter(d => d.stage === stage);
    return {
      name: stage.replace('_', ' '),
      SA: stageDeals.filter(d => d.market === 'SA').length,
      UK: stageDeals.filter(d => d.market === 'UK').length,
      US: stageDeals.filter(d => d.market === 'US').length,
    };
  });

  const hotDeals = [...safeDeals]
    .filter(d => ['DISCOVERY', 'PROPOSAL', 'NEGOTIATION'].includes(d.stage))
    .sort((a, b) => Number(b.value) - Number(a.value))
    .slice(0, 5);

  const staleDeals = [...deals]
    .filter(d => {
      if (!d.lastActivityAt) return false;
      const days = (new Date().getTime() - new Date(d.lastActivityAt).getTime()) / (1000 * 3600 * 24);
      return days > 7 && !['CLOSED_WON', 'CLOSED_LOST'].includes(d.stage);
    })
    .sort((a, b) => new Date(a.lastActivityAt).getTime() - new Date(b.lastActivityAt).getTime())
    .slice(0, 5);

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold font-sans tracking-tight text-white">Dashboard</h1>

      {/* Value Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-[#0A0A0A] p-6 rounded-2xl shadow-sm border border-white/5">
          <h3 className="text-xs font-semibold text-zinc-500 uppercase tracking-widest mb-2">Total Pipeline (ZAR)</h3>
          <p className="text-4xl font-light font-mono text-white">R{zarTotal.toLocaleString()}</p>
          <div className="mt-6 pt-4 border-t border-white/5">
            <h4 className="text-[10px] font-semibold text-zinc-500 uppercase tracking-widest mb-1">Forecasted Revenue</h4>
            <p className="text-lg font-mono font-medium text-[#4ECDE4]">R{Math.round(zarForecast).toLocaleString()}</p>
          </div>
        </div>
        <div className="bg-[#0A0A0A] p-6 rounded-2xl shadow-sm border border-white/5">
          <h3 className="text-xs font-semibold text-zinc-500 uppercase tracking-widest mb-2">Total Pipeline (GBP)</h3>
          <p className="text-4xl font-light font-mono text-white">£{gbpTotal.toLocaleString()}</p>
          <div className="mt-6 pt-4 border-t border-white/5">
            <h4 className="text-[10px] font-semibold text-zinc-500 uppercase tracking-widest mb-1">Forecasted Revenue</h4>
            <p className="text-lg font-mono font-medium text-[#4ECDE4]">£{Math.round(gbpForecast).toLocaleString()}</p>
          </div>
        </div>
        <div className="bg-[#0A0A0A] p-6 rounded-2xl shadow-sm border border-white/5">
          <h3 className="text-xs font-semibold text-zinc-500 uppercase tracking-widest mb-2">Total Pipeline (USD)</h3>
          <p className="text-4xl font-light font-mono text-white">${usdTotal.toLocaleString()}</p>
          <div className="mt-6 pt-4 border-t border-white/5">
            <h4 className="text-[10px] font-semibold text-zinc-500 uppercase tracking-widest mb-1">Forecasted Revenue</h4>
            <p className="text-lg font-mono font-medium text-[#4ECDE4]">${Math.round(usdForecast).toLocaleString()}</p>
          </div>
        </div>
      </div>

      {/* Chart */}
      <div className="bg-[#0A0A0A] p-6 rounded-2xl shadow-lg border border-white/5">
        <h3 className="text-lg font-semibold text-white mb-6">Deals by Stage</h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: "#a1a1aa", fontSize: 12}} />
              <YAxis axisLine={false} tickLine={false} tick={{fill: "#a1a1aa", fontSize: 12}} />
              <Tooltip cursor={{fill: '#141414'}} />
              <Legend />
              <Bar dataKey="SA" stackId="a" fill="#4ECDE4" radius={[0, 0, 4, 4]} />
              <Bar dataKey="UK" stackId="a" fill="#6853DB" />
              <Bar dataKey="US" stackId="a" fill="#a1a1aa" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Hot Deals */}
        <div className="bg-[#0A0A0A] p-6 rounded-2xl shadow-lg border border-white/5">
          <h3 className="text-lg font-semibold text-white mb-4">Hot Deals (Discovery+)</h3>
          <div className="space-y-4">
            {hotDeals.map(deal => (
              <div key={deal.id} className="flex justify-between items-center p-4 bg-[#141414] rounded-xl border border-white/5 hover:bg-[#1a1a1a] transition-colors">
                <div>
                  <h4 className="font-medium text-white">{deal.title}</h4>
                  <p className="text-sm text-zinc-400">{deal.company?.name} • {deal.stage.replace('_', ' ')}</p>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-white">
                    {deal.currency === 'ZAR' ? 'R' : deal.currency === 'GBP' ? '£' : '$'}{Number(deal.value).toLocaleString()}
                  </p>
                  <p className="text-xs text-zinc-400">{deal.market}</p>
                </div>
              </div>
            ))}
            {hotDeals.length === 0 && <p className="text-zinc-400 text-sm">No hot deals found.</p>}
          </div>
        </div>

        {/* Stale Deals */}
        <div className="bg-[#0A0A0A] p-6 rounded-2xl shadow-lg border border-white/5">
          <h3 className="text-lg font-semibold text-white mb-4">Stale Deals</h3>
          <div className="space-y-4">
            {staleDeals.map(deal => {
              const days = (new Date().getTime() - new Date(deal.lastActivityAt).getTime()) / (1000 * 3600 * 24);
              const isRed = days > 14;
              return (
                <div key={deal.id} className="flex justify-between items-center p-4 bg-[#141414] rounded-xl border border-white/5 hover:bg-[#1a1a1a] transition-colors border-l-4 border-transparent" style={{ borderLeftColor: isRed ? '#ef4444' : '#f59e0b' }}>
                  <div>
                    <h4 className="font-medium text-white">{deal.title}</h4>
                    <p className="text-sm text-zinc-400">{deal.company?.name}</p>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-medium ${isRed ? 'text-red-400' : 'text-amber-400'}`}>
                      {Math.floor(days)} days idle
                    </p>
                    <p className="text-xs text-zinc-400">{deal.stage.replace('_', ' ')}</p>
                  </div>
                </div>
              );
            })}
            {staleDeals.length === 0 && <p className="text-zinc-400 text-sm">No stale deals found.</p>}
          </div>
        </div>
      </div>
    </div>
  );
}
