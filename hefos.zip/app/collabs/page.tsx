'use client';

import { useState, useEffect } from 'react';
import { getCurrentUser } from '@/lib/auth';
import Link from 'next/link';

export default function CollabsPage() {
  const [collabs, setCollabs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [saving, setSaving] = useState(false);
  
  const user = getCurrentUser();

  useEffect(() => {
    fetchCollabs();
  }, []);

  const fetchCollabs = async () => {
    try {
      const res = await fetch('/api/collabs');
      const data = await res.json();
      setCollabs(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    
    setSaving(true);
    try {
      const res = await fetch('/api/collabs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, description, userId: user.id })
      });
      if (res.ok) {
        setIsModalOpen(false);
        setName('');
        setDescription('');
        fetchCollabs();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="h-full flex flex-col">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold font-sans tracking-tight text-white">Collabs</h1>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="bg-white text-[#050505] px-4 py-2 rounded-lg text-sm font-semibold hover:bg-zinc-200 transition-colors"
        >
          + New Collab
        </button>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {loading ? (
          <div className="flex-1 flex justify-center items-center text-zinc-500">Loading...</div>
        ) : collabs.length > 0 ? (
          <div className="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 overflow-y-auto custom-scrollbar content-start">
            {collabs.map(collab => (
              <Link href={`/collabs/${collab.id}`} key={collab.id} className="bg-[#0A0A0A] rounded-2xl border border-white/5 p-6 shadow-lg hover:border-white/10 transition-colors flex flex-col cursor-pointer">
                <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-white font-bold text-xl mb-4">
                  {collab.name.charAt(0).toUpperCase()}
                </div>
                <h3 className="text-lg font-bold text-white mb-1">{collab.name}</h3>
                <p className="text-[13px] text-zinc-400 mb-6 flex-1 line-clamp-3">{collab.description || 'No description provided.'}</p>
                
                <div className="flex justify-between items-center pt-4 border-t border-white/5">
                  <div className="flex -space-x-2">
                    {collab.members.slice(0, 3).map((m: any) => (
                      <div key={m.id} className="w-6 h-6 rounded-full bg-[#141414] border border-[#0A0A0A] flex items-center justify-center text-[10px] text-white font-bold" title={m.user?.name}>
                        {m.user?.name?.charAt(0)}
                      </div>
                    ))}
                    {collab.members.length > 3 && (
                      <div className="w-6 h-6 rounded-full bg-white/10 border border-[#0A0A0A] flex items-center justify-center text-[10px] text-zinc-400 font-mono">
                        +{collab.members.length - 3}
                      </div>
                    )}
                  </div>
                  <div className="text-[11px] text-zinc-500 font-mono">
                    {collab._count?.tasks || 0} tasks
                  </div>
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <div className="flex-1 flex bg-[#0A0A0A] rounded-2xl border border-white/5 overflow-hidden">
            <div className="flex-1 flex flex-col items-center justify-center p-8">
              <div className="w-32 h-32 mb-6 opacity-30 bg-white/5 rounded-3xl flex items-center justify-center">
                <span className="text-4xl">👥</span>
              </div>
              <p className="text-zinc-400 text-center max-w-xs text-sm">
                You aren&apos;t a member of any Collabs yet. Click the button above to create one.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
          <div className="bg-[#0A0A0A] rounded-2xl w-full max-w-lg border border-white/10 shadow-2xl p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-white tracking-tight">Create Collab</h2>
              <button onClick={() => setIsModalOpen(false)} className="text-zinc-500 hover:text-white">&times;</button>
            </div>
            
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-[11px] font-mono text-zinc-500 uppercase tracking-widest mb-2">Collab Name</label>
                <input 
                  required 
                  type="text" 
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full bg-transparent border-b border-white/20 pb-2 text-white text-sm focus:outline-none focus:border-white transition-colors" 
                  placeholder="e.g. Q3 Marketing Launch"
                />
              </div>
              <div>
                <label className="block text-[11px] font-mono text-zinc-500 uppercase tracking-widest mb-2 mt-6">Description</label>
                <textarea 
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-white text-sm min-h-[100px] focus:outline-none focus:border-white/20 resize-none transition-colors" 
                  placeholder="What is this collab for?"
                />
              </div>
              
              <div className="pt-6 flex justify-end gap-3 border-t border-white/5 mt-4">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 rounded-lg text-sm font-semibold text-zinc-500 hover:text-white transition-colors">Cancel</button>
                <button type="submit" disabled={saving || !name.trim()} className="bg-white text-[#050505] px-6 py-2 rounded-lg text-sm font-semibold disabled:opacity-50 transition-opacity">
                  {saving ? 'Creating...' : 'Create Collab'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
