import { prisma } from '@/lib/prisma';
import { notFound } from 'next/navigation';
import CollabDetailClient from './CollabDetailClient';

export default async function CollabDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const resolvedParams = await params;
  const collab = await prisma.collab.findUnique({
    where: { id: resolvedParams.id },
    include: {
      members: {
        include: { user: { select: { name: true, avatar: true, email: true } } }
      },
      tasks: {
        include: {
          assignee: { select: { name: true, avatar: true } },
          creator: { select: { name: true, avatar: true } }
        },
        orderBy: { createdAt: 'desc' }
      }
    }
  });

  if (!collab) {
    notFound();
  }

  return <CollabDetailClient collab={collab} />;
}
