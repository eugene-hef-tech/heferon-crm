'use client';

import { useState } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { getCurrentUser } from '@/lib/auth';
import Link from 'next/link';

export default function CollabDetailClient({ collab: initialCollab }: { collab: any }) {
  const [collab, setCollab] = useState(initialCollab);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [taskTitle, setTaskTitle] = useState('');
  const [taskDescription, setTaskDescription] = useState('');
  const [taskDueDate, setTaskDueDate] = useState('');
  const [assigneeId, setAssigneeId] = useState('');
  const [savingTask, setSavingTask] = useState(false);

  const user = getCurrentUser();

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle.trim()) return;

    setSavingTask(true);
    try {
      const res = await fetch(`/api/collabs/${collab.id}/tasks`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: taskTitle,
          description: taskDescription,
          dueDate: taskDueDate ? new Date(taskDueDate).toISOString() : undefined,
          assigneeId: assigneeId || undefined,
          creatorId: user.id
        })
      });

      if (res.ok) {
        const newTask = await res.json();
        setCollab({
          ...collab,
          tasks: [newTask, ...collab.tasks]
        });
        setIsTaskModalOpen(false);
        setTaskTitle('');
        setTaskDescription('');
        setTaskDueDate('');
        setAssigneeId('');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSavingTask(false);
    }
  };

  const handleUpdateTaskStatus = async (taskId: string, newStatus: string) => {
    try {
      const res = await fetch(`/api/tasks/${taskId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });
      if (res.ok) {
        const updatedTask = await res.json();
        setCollab({
          ...collab,
          tasks: collab.tasks.map((t: any) => t.id === taskId ? updatedTask : t)
        });
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="h-full flex flex-col space-y-6">
      <div className="flex items-center gap-4 border-b border-white/5 pb-6">
        <Link href="/collabs" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-zinc-400 hover:bg-white/10 hover:text-white transition-colors">
          &larr;
        </Link>
        <div>
          <h1 className="text-2xl font-bold font-sans tracking-tight text-white">{collab.name}</h1>
          <p className="text-zinc-500 text-sm mt-1">{collab.description}</p>
        </div>
        <div className="ml-auto flex -space-x-2">
          {collab.members.map((m: any) => (
            <div key={m.id} className="w-8 h-8 rounded-full bg-[#141414] border-2 border-[#0A0A0A] flex items-center justify-center text-xs text-white font-bold" title={m.user?.name}>
              {m.user?.name?.charAt(0)}
            </div>
          ))}
        </div>
      </div>

      <div className="flex justify-between items-center">
        <h2 className="text-lg font-bold text-white">Tasks</h2>
        <button 
          onClick={() => setIsTaskModalOpen(true)}
          className="bg-white text-[#050505] px-4 py-2 rounded-lg text-sm font-semibold hover:bg-zinc-200 transition-colors"
        >
          + New Task
        </button>
      </div>

      <div className="flex-1 bg-[#0A0A0A] rounded-2xl border border-white/5 overflow-hidden flex flex-col">
        {collab.tasks.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8">
            <div className="text-4xl mb-4 opacity-50">📋</div>
            <p className="text-zinc-400 text-sm">No tasks in this collab yet.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-[13px] border-collapse">
              <thead>
                <tr className="border-b border-white/5">
                  <th className="p-4 font-mono text-[10px] uppercase text-zinc-500 tracking-widest">Task</th>
                  <th className="p-4 font-mono text-[10px] uppercase text-zinc-500 tracking-widest">Status</th>
                  <th className="p-4 font-mono text-[10px] uppercase text-zinc-500 tracking-widest">Assignee</th>
                  <th className="p-4 font-mono text-[10px] uppercase text-zinc-500 tracking-widest">Due Date</th>
                  <th className="p-4 font-mono text-[10px] uppercase text-zinc-500 tracking-widest">Created</th>
                </tr>
              </thead>
              <tbody>
                {collab.tasks.map((task: any) => (
                  <tr key={task.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="p-4">
                      <div className="font-medium text-white">{task.title}</div>
                      {task.description && <div className="text-xs text-zinc-500 mt-1 truncate max-w-xs">{task.description}</div>}
                    </td>
                    <td className="p-4">
                      <select 
                        value={task.status} 
                        onChange={(e) => handleUpdateTaskStatus(task.id, e.target.value)}
                        className={`text-[10px] px-2 py-1 rounded-md font-semibold cursor-pointer outline-none appearance-none ${
                          task.status === 'PENDING' ? 'bg-zinc-500/20 text-zinc-400' :
                          task.status === 'ONGOING' ? 'bg-blue-500/20 text-blue-400' :
                          'bg-[#00E096]/20 text-[#00E096]'
                        }`}
                      >
                        <option value="PENDING">PENDING</option>
                        <option value="ONGOING">ONGOING</option>
                        <option value="DONE">DONE</option>
                      </select>
                    </td>
                    <td className="p-4 text-zinc-400">{task.assignee?.name || 'Unassigned'}</td>
                    <td className="p-4 text-zinc-400">
                      {task.dueDate ? new Date(task.dueDate).toLocaleDateString() : '-'}
                    </td>
                    <td className="p-4 text-zinc-500">
                      {formatDistanceToNow(new Date(task.createdAt), { addSuffix: true })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Task Modal */}
      {isTaskModalOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
          <div className="bg-[#0A0A0A] rounded-2xl w-full max-w-lg border border-white/10 shadow-2xl p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-white tracking-tight">Create Task</h2>
              <button onClick={() => setIsTaskModalOpen(false)} className="text-zinc-500 hover:text-white">&times;</button>
            </div>
            
            <form onSubmit={handleCreateTask} className="space-y-4">
              <div>
                <label className="block text-[11px] font-mono text-zinc-500 uppercase tracking-widest mb-2">Task Title</label>
                <input 
                  required 
                  type="text" 
                  value={taskTitle}
                  onChange={e => setTaskTitle(e.target.value)}
                  className="w-full bg-transparent border-b border-white/20 pb-2 text-white text-sm focus:outline-none focus:border-white transition-colors" 
                  placeholder="e.g. Review Q3 metrics"
                />
              </div>
              <div>
                <label className="block text-[11px] font-mono text-zinc-500 uppercase tracking-widest mb-2 mt-6">Description</label>
                <textarea 
                  value={taskDescription}
                  onChange={e => setTaskDescription(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-white text-sm min-h-[80px] focus:outline-none focus:border-white/20 resize-none transition-colors" 
                  placeholder="Additional details..."
                />
              </div>

              <div className="grid grid-cols-2 gap-4 mt-6">
                <div>
                  <label className="block text-[11px] font-mono text-zinc-500 uppercase tracking-widest mb-2">Due Date</label>
                  <input 
                    type="date" 
                    value={taskDueDate}
                    onChange={e => setTaskDueDate(e.target.value)}
                    className="w-full bg-transparent border-b border-white/20 pb-2 text-white text-[13px] focus:outline-none focus:border-white transition-colors color-scheme-dark"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-mono text-zinc-500 uppercase tracking-widest mb-2">Assignee</label>
                  <select 
                    value={assigneeId}
                    onChange={e => setAssigneeId(e.target.value)}
                    className="w-full bg-[#0A0A0A] border-b border-white/20 pb-2 text-white text-sm focus:outline-none focus:border-white transition-colors"
                  >
                    <option value="">Unassigned</option>
                    {collab.members.map((m: any) => (
                      <option key={m.userId} value={m.userId}>{m.user?.name}</option>
                    ))}
                  </select>
                </div>
              </div>
              
              <div className="pt-6 flex justify-end gap-3 border-t border-white/5 mt-4">
                <button type="button" onClick={() => setIsTaskModalOpen(false)} className="px-4 py-2 rounded-lg text-sm font-semibold text-zinc-500 hover:text-white transition-colors">Cancel</button>
                <button type="submit" disabled={savingTask || !taskTitle.trim()} className="bg-white text-[#050505] px-6 py-2 rounded-lg text-sm font-semibold disabled:opacity-50 transition-opacity">
                  {savingTask ? 'Creating...' : 'Create Task'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
