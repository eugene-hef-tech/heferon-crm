import fs from 'fs';
import path from 'path';

function run() {
  const p = path.join(process.cwd(), 'app/dashboard/page.tsx');
  let c = fs.readFileSync(p, 'utf8');

  // Chart and card backgrounds
  c = c.replace(/bg-white p-6 rounded-xl shadow-sm border border-gray-200/g, 'bg-[#0A0A0A] p-6 rounded-2xl shadow-lg border border-white/5');
  
  // Texts
  c = c.replace(/text-gray-900/g, 'text-white');
  c = c.replace(/text-gray-500/g, 'text-zinc-400');
  
  // Inner List Item BGs
  c = c.replace(/bg-gray-50 rounded-lg/g, 'bg-[#141414] rounded-xl border border-white/5 hover:bg-[#1a1a1a] transition-colors');
  c = c.replace(/border-transparent/g, 'border-transparent');
  
  c = c.replace(/text-red-600/g, 'text-red-400');
  c = c.replace(/text-amber-600/g, 'text-amber-400');
  
  // Chart Colors
  c = c.replace(/fill="#3b82f6"/g, 'fill="#4ECDE4"');
  c = c.replace(/fill="#a855f7"/g, 'fill="#6853DB"');
  c = c.replace(/fill="#10b981"/g, 'fill="#a1a1aa"');
  
  // Tick lines
  c = c.replace(/axisLine=\{false\} tickLine=\{false\}/g, 'axisLine={false} tickLine={false} tick={{fill: "#a1a1aa", fontSize: 12}}');
  c = c.replace(/cursor=\{\{fill: '#f3f4f6'\}\}/g, "cursor={{fill: '#141414'}}");
  
  fs.writeFileSync(p, c);
  console.log('Fixed dashboard elements.');
}

run();
