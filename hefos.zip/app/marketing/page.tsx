export default function MarketingPage() {
  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Start</h1>
      </div>

      <div className="space-y-4">
        <h2 className="text-sm font-semibold text-[zinc-400] uppercase tracking-wider">Create Campaign</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
          <div className="bg-[#0A0A0A] border border-white/5 rounded-2xl p-6 flex flex-col items-center justify-center gap-4 hover:bg-white/5 transition-colors cursor-pointer">
            <div className="w-12 h-12 rounded-full bg-[white] flex items-center justify-center text-white">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
            </div>
            <span className="text-sm font-medium text-white">Email Campaign</span>
          </div>
          <div className="bg-[#0A0A0A] border border-white/5 rounded-2xl p-6 flex flex-col items-center justify-center gap-4 hover:bg-white/5 transition-colors cursor-pointer">
            <div className="w-12 h-12 rounded-full bg-[#FF3D71] flex items-center justify-center text-white">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
            </div>
            <span className="text-sm font-medium text-white">SMS Campaign</span>
          </div>
          <div className="bg-[#0A0A0A] border border-white/5 rounded-2xl p-6 flex flex-col items-center justify-center gap-4 hover:bg-white/5 transition-colors cursor-pointer">
            <div className="w-12 h-12 rounded-full bg-[#00E096] flex items-center justify-center text-white">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect><line x1="12" y1="18" x2="12.01" y2="18"></line></svg>
            </div>
            <span className="text-sm font-medium text-white">Messengers</span>
          </div>
          <div className="bg-[#0A0A0A] border border-white/5 rounded-2xl p-6 flex flex-col items-center justify-center gap-4 hover:bg-white/5 transition-colors cursor-pointer">
            <div className="w-12 h-12 rounded-full bg-[#6853DB] flex items-center justify-center text-white">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
            </div>
            <span className="text-sm font-medium text-white text-center">Voice broadcasting</span>
          </div>
          <div className="bg-[#0A0A0A] border border-white/5 rounded-2xl p-6 flex flex-col items-center justify-center gap-4 hover:bg-white/5 transition-colors cursor-pointer">
            <div className="w-12 h-12 rounded-full bg-[white] flex items-center justify-center text-white">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
            </div>
            <span className="text-sm font-medium text-white">Audio call</span>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h2 className="text-sm font-semibold text-[zinc-400] uppercase tracking-wider">Create audience</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
          <div className="bg-[#0A0A0A] border border-white/5 rounded-2xl p-6 flex flex-col items-center justify-center gap-4 hover:bg-white/5 transition-colors cursor-pointer">
            <div className="w-12 h-12 rounded-full bg-[#4285F4] flex items-center justify-center text-white font-bold text-xl">
              A
            </div>
            <span className="text-sm font-medium text-white">Google Ads</span>
          </div>
          <div className="bg-[#0A0A0A] border border-white/5 rounded-2xl p-6 flex flex-col items-center justify-center gap-4 hover:bg-white/5 transition-colors cursor-pointer">
            <div className="w-12 h-12 rounded-full bg-[#1877F2] flex items-center justify-center text-white font-bold text-xl">
              f
            </div>
            <span className="text-sm font-medium text-white text-center">Facebook audiences ...</span>
          </div>
          <div className="bg-[#0A0A0A] border border-white/5 rounded-2xl p-6 flex flex-col items-center justify-center gap-4 hover:bg-white/5 transition-colors cursor-pointer">
            <div className="w-12 h-12 rounded-full bg-[#1877F2] flex items-center justify-center text-white font-bold text-xl">
              f
            </div>
            <span className="text-sm font-medium text-white text-center">Facebook lookalike a...</span>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h2 className="text-sm font-semibold text-[zinc-400] uppercase tracking-wider">Promoted posts</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
          <div className="bg-[#0A0A0A] border border-white/5 rounded-2xl p-6 flex flex-col items-center justify-center gap-4 hover:bg-white/5 transition-colors cursor-pointer">
            <div className="w-12 h-12 rounded-full bg-[#1877F2] flex items-center justify-center text-white font-bold text-xl">
              f
            </div>
          </div>
          <div className="bg-[#0A0A0A] border border-white/5 rounded-2xl p-6 flex flex-col items-center justify-center gap-4 hover:bg-white/5 transition-colors cursor-pointer">
            <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-[#F58529] via-[#DD2A7B] to-[#8134AF] flex items-center justify-center text-white font-bold text-xl">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
