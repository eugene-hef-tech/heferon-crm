export default function ContactCenterPage() {
  const channels = [
    { name: 'Mail', icon: 'M', color: 'bg-[#8DC63F]' },
    { name: 'Telephony', icon: 'T', color: 'bg-[white]' },
    { name: 'Call tracking', icon: 'C', color: 'bg-[#00E096]' },
    { name: 'CRM+Online Store', icon: 'S', color: 'bg-[#FF3D71]', badge: 'NEW' },
    { name: 'Website widget', icon: 'W', color: 'bg-[#FFAB00]' },
    { name: 'Website form', icon: 'F', color: 'bg-[white]' },
    { name: 'Live chat', icon: 'L', color: 'bg-[#FFAB00]', active: true },
    { name: 'WhatsApp', icon: 'W', color: 'bg-[#25D366]' },
    { name: 'Viber', icon: 'V', color: 'bg-[#665CAC]' },
    { name: 'Telegram', icon: 'T', color: 'bg-[#0088CC]' },
    { name: 'Apple Messages for Business', icon: 'A', color: 'bg-[#00E096]' },
    { name: 'Facebook', icon: 'F', color: 'bg-[#1877F2]' },
    { name: 'Facebook: Comments', icon: 'F', color: 'bg-[#3B5998]' },
    { name: 'Instagram Direct', icon: 'I', color: 'bg-[#E1306C]' },
    { name: 'Bitrix24 Network', icon: 'B', color: 'bg-[white]' },
    { name: 'Instant WhatsApp', icon: 'W', color: 'bg-[#25D366]' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Contact Center</h1>
      </div>

      <div className="bg-[#0A0A0A] rounded-2xl border border-white/5 p-8">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {channels.map((channel, idx) => (
            <div 
              key={idx} 
              className={`relative rounded-xl p-6 flex flex-col items-center justify-center gap-4 cursor-pointer transition-colors ${
                channel.active 
                  ? 'bg-[#FFAB00] text-white' 
                  : 'bg-white/5 border border-white/5 hover:bg-white/10 text-white'
              }`}
            >
              {channel.badge && (
                <span className="absolute top-2 right-2 bg-[white] text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                  {channel.badge}
                </span>
              )}
              {channel.active && (
                <div className="absolute top-2 right-2 w-5 h-5 bg-[#00E096] rounded-full flex items-center justify-center border-2 border-[#FFAB00]">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                </div>
              )}
              <div className={`w-12 h-12 rounded-full ${channel.active ? 'bg-white/20' : channel.color} flex items-center justify-center text-white font-bold text-xl`}>
                {channel.icon}
              </div>
              <span className="text-sm font-medium text-center">{channel.name}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
