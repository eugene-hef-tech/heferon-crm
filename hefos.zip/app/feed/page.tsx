'use client';

import { useState, useEffect } from 'react';
import { getCurrentUser } from '@/lib/auth';
import { formatDistanceToNow } from 'date-fns';
import Image from 'next/image';

export default function FeedPage() {
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [newPostContent, setNewPostContent] = useState('');
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});
  
  const user = getCurrentUser();

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    try {
      const res = await fetch('/api/feed');
      const data = await res.json();
      setPosts(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handlePostSubmit = async () => {
    if (!newPostContent.trim()) return;
    
    try {
      const res = await fetch('/api/feed', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: newPostContent,
          type: 'MESSAGE',
          userId: user.id
        })
      });
      
      if (res.ok) {
        setNewPostContent('');
        fetchPosts(); // Refresh feed
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleCommentSubmit = async (postId: string) => {
    const comment = commentInputs[postId];
    if (!comment?.trim()) return;
    
    try {
      const res = await fetch(`/api/feed/${postId}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: comment,
          userId: user.id
        })
      });
      
      if (res.ok) {
        setCommentInputs(prev => ({ ...prev, [postId]: '' }));
        fetchPosts(); // refresh feed
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold font-sans tracking-tight text-white">Feed</h1>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Post Input */}
          <div className="bg-[#0A0A0A] rounded-2xl border border-white/5 p-4 shadow-lg">
            <div className="flex gap-4 mb-4 text-xs font-semibold text-zinc-500 uppercase tracking-widest border-b border-white/5 pb-2">
              <button className="text-white border-b border-white pb-1 -mb-[9px]">MESSAGE</button>
              <button className="hover:text-white transition-colors pb-1">EVENT</button>
              <button className="hover:text-white transition-colors pb-1">POLL</button>
            </div>
            <textarea 
              placeholder="Send message to everyone..." 
              value={newPostContent}
              onChange={(e) => setNewPostContent(e.target.value)}
              className="w-full bg-transparent border-none focus:ring-0 text-white placeholder-[zinc-500] resize-none h-20 text-[13px] font-sans"
            />
            <div className="flex justify-end pt-2">
              <button 
                onClick={handlePostSubmit}
                disabled={!newPostContent.trim()}
                className="bg-white text-[#050505] font-semibold text-xs px-6 py-2 rounded-lg hover:bg-zinc-200 transition-colors disabled:opacity-50"
              >
                Send
              </button>
            </div>
          </div>

          {/* Feed Items */}
          <div className="space-y-4">
            {loading ? (
              <div className="text-zinc-500 text-sm">Loading feed...</div>
            ) : posts.length === 0 ? (
              <div className="text-zinc-500 text-sm">No posts in the feed yet. Be the first to post!</div>
            ) : (
              posts.map(post => (
                <div key={post.id} className="bg-[#0A0A0A] rounded-2xl border border-white/5 p-6 shadow-lg">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white font-bold text-sm overflow-hidden relative">
                      {post.user?.avatar ? <Image src={post.user.avatar} fill className="object-cover" alt="avatar" /> : post.user?.name?.charAt(0) || 'U'}
                    </div>
                    <div>
                      <div className="text-[13px] font-medium text-white">{post.user?.name || 'Unknown User'} <span className="text-zinc-500 font-normal">› To all employees</span></div>
                      <div className="text-xs text-zinc-500 font-mono mt-0.5">{formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}</div>
                    </div>
                  </div>
                  <p className="text-[#E4E3E0] mb-5 text-[13px] font-sans whitespace-pre-wrap leading-relaxed">{post.content}</p>
                  
                  {/* Comments Section */}
                  <div className="border-t border-white/5 pt-4">
                    {post.comments?.length > 0 && (
                      <div className="space-y-4 mb-4 pl-2">
                        {post.comments.map((comment: any) => (
                          <div key={comment.id} className="flex gap-3">
                            <div className="w-6 h-6 shrink-0 rounded-full bg-white/10 flex items-center justify-center text-xs text-white font-bold">
                              {comment.user?.name?.charAt(0) || 'U'}
                            </div>
                            <div>
                              <div className="text-xs text-zinc-400">
                                <span className="text-white font-medium mr-2">{comment.user?.name || 'Unknown'}</span>
                                <span className="font-mono text-[10px]">{formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}</span>
                              </div>
                              <p className="text-[13px] text-[#E4E3E0] mt-0.5">{comment.content}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                    
                    <div className="flex gap-3 items-center mt-2">
                      <input 
                        type="text" 
                        placeholder="Write a comment..." 
                        value={commentInputs[post.id] || ''}
                        onChange={(e) => setCommentInputs(prev => ({ ...prev, [post.id]: e.target.value }))}
                        onKeyDown={(e) => e.key === 'Enter' && handleCommentSubmit(post.id)}
                        className="flex-1 bg-white/5 border border-white/5 rounded-lg py-1.5 px-3 text-[13px] text-white focus:outline-none focus:border-white/20 transition-colors placeholder-zinc-500"
                      />
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="space-y-6">
          {/* Right Sidebar Widgets */}
          <div className="bg-[#0A0A0A] rounded-2xl border border-white/5 p-6 shadow-lg">
            <h3 className="font-semibold text-xs text-zinc-500 uppercase tracking-widest mb-4">My Tasks</h3>
            <div className="space-y-3 text-[13px]">
              <div className="flex justify-between text-zinc-400 hover:text-white cursor-pointer transition-colors">
                <span>Ongoing</span>
                <span className="font-mono">0</span>
              </div>
              <div className="flex justify-between text-zinc-400 hover:text-white cursor-pointer transition-colors">
                <span>Assisting</span>
                <span className="font-mono">0</span>
              </div>
              <div className="flex justify-between text-zinc-400 hover:text-white cursor-pointer transition-colors">
                <span>Set by me</span>
                <span className="font-mono">0</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
