'use client';

import { useState, useEffect } from 'react';
import { Phone, Mail, MessageSquare, Calendar, FileText, CheckCircle } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export default function ActivitiesPage() {
  const [activities, setActivities] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchActivities();
  }, []);

  const fetchActivities = async () => {
    try {
      const res = await fetch('/api/activities');
      const data = await res.json();
      setActivities(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'CALL': return <Phone size={18} className="text-[white]" />;
      case 'EMAIL': return <Mail size={18} className="text-[#FFAB00]" />;
      case 'LINKEDIN_MESSAGE': return <MessageSquare size={18} className="text-[#6853DB]" />;
      case 'MEETING':
      case 'DISCOVERY_CALL': return <Calendar size={18} className="text-[#00E096]" />;
      case 'PROPOSAL_SENT': return <FileText size={18} className="text-[#FFD700]" />;
      default: return <CheckCircle size={18} className="text-[zinc-400]" />;
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Activities Feed</h1>
        <button className="bg-[#0A0A0A] text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-white/10 transition-colors border border-white/5 text-sm font-medium">
          <span>Log Activity</span>
        </button>
      </div>

      <div className="bg-[#0A0A0A] rounded-2xl border border-white/5 overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-[zinc-400]">Loading activities...</div>
        ) : activities.length === 0 ? (
          <div className="p-8 text-center text-[zinc-400]">No activities found.</div>
        ) : (
          <div className="divide-y divide-white/5">
            {activities.map(activity => (
              <div key={activity.id} className="p-6 flex gap-4 hover:bg-white/5 transition-colors">
                <div className="mt-1">
                  {getActivityIcon(activity.type)}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-start mb-1">
                    <h4 className="font-medium text-white">{activity.subject}</h4>
                    <span className="text-xs text-[zinc-400]">
                      {formatDistanceToNow(new Date(activity.createdAt), { addSuffix: true })}
                    </span>
                  </div>
                  <p className="text-sm text-[zinc-400] mb-3">{activity.description}</p>
                  <div className="flex gap-2 text-[11px] text-[zinc-400]">
                    {activity.deal && (
                      <span className="bg-white/5 border border-white/10 px-2 py-1 rounded-md">Deal: {activity.deal.title}</span>
                    )}
                    {activity.contact && (
                      <span className="bg-white/5 border border-white/10 px-2 py-1 rounded-md">Contact: {activity.contact.firstName} {activity.contact.lastName}</span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
