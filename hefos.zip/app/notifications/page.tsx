'use client';

import { useState, useEffect } from 'react';
import { formatDistanceToNow } from 'date-fns';

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchNotifications();
  }, []);

  const fetchNotifications = async () => {
    try {
      const res = await fetch('/api/notifications');
      const data = await res.json();
      setNotifications(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleMarkAsRead = async (id: string) => {
    try {
      const res = await fetch('/api/notifications', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, isRead: true })
      });
      if (res.ok) {
        setNotifications(notifications.map(n => n.id === id ? { ...n, isRead: true } : n));
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="h-full flex flex-col space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold font-sans tracking-tight text-white">Notifications</h1>
      </div>

      <div className="flex-1 bg-[#0A0A0A] rounded-2xl border border-white/5 overflow-hidden flex flex-col">
        {loading ? (
          <div className="flex-1 flex justify-center items-center text-zinc-500">Loading...</div>
        ) : notifications.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8">
            <div className="text-4xl mb-4 opacity-30">🔔</div>
            <p className="text-zinc-400 text-sm">No new notifications.</p>
          </div>
        ) : (
          <div className="overflow-y-auto custom-scrollbar flex-1 divide-y divide-white/5">
            {notifications.map(notification => (
              <div 
                key={notification.id} 
                className={`p-6 transition-colors flex gap-4 ${notification.isRead ? 'bg-[#0A0A0A]' : 'bg-white/5'}`}
              >
                <div className="pt-1">
                  {notification.type === 'DEAL_STAGE_CHANGE' ? (
                    <div className="w-8 h-8 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center text-sm">📊</div>
                  ) : notification.type === 'NEW_LEAD' ? (
                    <div className="w-8 h-8 rounded-full bg-[#00E096]/20 text-[#00E096] flex items-center justify-center text-sm">✨</div>
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-zinc-500/20 text-zinc-400 flex items-center justify-center text-sm">🔔</div>
                  )}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-start mb-1">
                    <h3 className={`text-sm ${notification.isRead ? 'text-zinc-300' : 'text-white font-bold'}`}>
                      {notification.title}
                    </h3>
                    <span className="text-[11px] text-zinc-500 font-mono">
                      {formatDistanceToNow(new Date(notification.createdAt), { addSuffix: true })}
                    </span>
                  </div>
                  <p className="text-[13px] text-zinc-400 leading-relaxed mb-3">
                    {notification.body}
                  </p>
                  
                  {!notification.isRead && (
                    <button 
                      onClick={() => handleMarkAsRead(notification.id)}
                      className="text-[11px] font-mono uppercase tracking-widest text-zinc-500 hover:text-white transition-colors"
                    >
                      Mark as read
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
