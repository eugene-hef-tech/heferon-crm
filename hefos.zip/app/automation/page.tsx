export default function AutomationPage() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Robotic Process Automation (RPA)</h1>
      </div>

      <div className="flex gap-4 border-b border-white/5 pb-4 mb-6">
        <button className="text-white border-b-2 border-white pb-1 font-medium">Details</button>
        <button className="text-zinc-400 hover:text-white transition-colors pb-1">List</button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white/5 border-2 border-dashed border-white/20 rounded-2xl p-12 flex flex-col items-center justify-center gap-4 hover:bg-white/10 transition-colors cursor-pointer min-h-[200px]">
          <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center text-white text-3xl font-light">
            +
          </div>
          <span className="text-lg font-medium text-white">New workflow</span>
        </div>
      </div>
    </div>
  );
}
