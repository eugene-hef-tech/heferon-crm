import fs from 'fs';
import path from 'path';

function run() {
  const files = [
    'app/marketing/page.tsx',
    'app/feed/page.tsx', 
    'app/integrations/page.tsx',
    'app/contact-center/page.tsx',
    'app/collabs/page.tsx'
  ];
  
  for (const f of files) {
    const p = path.join(process.cwd(), f);
    if (fs.existsSync(p)) {
      let content = fs.readFileSync(p, 'utf8');
      content = content.replace(/#161B3D/g, '#0A0A0A');
      content = content.replace(/bg-\[#0C0F26\]/g, 'bg-[#050505]');
      content = content.replace(/#8F9BB3/g, 'zinc-400');
      content = content.replace(/text-\[#8F9BB3\]/g, 'text-zinc-400');
      content = content.replace(/#4ECDE4/g, 'white');
      content = content.replace(/from-\[#4ECDE4\] to-\[#6853DB\]/g, 'from-white to-zinc-500');
      fs.writeFileSync(p, content);
    }
  }
}
run();
