import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const automations = await prisma.stageAutomation.findMany({
      orderBy: { createdAt: 'asc' }
    });
    return NextResponse.json(automations);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to fetch automations' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { stage, createActivity, activityType, activitySubject, sendNotification, notificationMessage } = body;

    const automation = await prisma.stageAutomation.upsert({
      where: { stage },
      update: {
        createActivity,
        activityType,
        activitySubject,
        sendNotification,
        notificationMessage
      },
      create: {
        stage,
        createActivity,
        activityType,
        activitySubject,
        sendNotification,
        notificationMessage
      }
    });

    return NextResponse.json(automation);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to save automation' }, { status: 500 });
  }
}
