import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await context.params;
    const body = await request.json();
    const { content, userId } = body;

    if (!content || !userId) {
      return NextResponse.json({ error: 'Missing content or userId' }, { status: 400 });
    }

    const newComment = await prisma.feedComment.create({
      data: {
        content,
        userId,
        postId: id
      },
      include: {
        user: { select: { name: true, avatar: true } }
      }
    });

    return NextResponse.json(newComment);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to add comment' }, { status: 500 });
  }
}
