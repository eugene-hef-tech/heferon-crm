import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const posts = await prisma.feedPost.findMany({
      include: {
        user: { select: { name: true, avatar: true } },
        comments: {
          include: { user: { select: { name: true, avatar: true } } },
          orderBy: { createdAt: 'asc' }
        }
      },
      orderBy: { createdAt: 'desc' }
    });
    return NextResponse.json(posts);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to fetch feed' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { content, type, userId } = body;
    
    if (!content || !userId) {
      return NextResponse.json({ error: 'Missing content or userId' }, { status: 400 });
    }

    const newPost = await prisma.feedPost.create({
      data: {
        content,
        type: type || 'MESSAGE',
        userId
      },
      include: {
        user: { select: { name: true, avatar: true } },
        comments: true
      }
    });

    return NextResponse.json(newPost);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to create post' }, { status: 500 });
  }
}
