import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const params = await context.params;
    const body = await request.json();
    const { status } = body;
    
    const task = await prisma.task.update({
      where: { id: params.id },
      data: { status },
      include: {
        assignee: { select: { name: true, avatar: true } },
        creator: { select: { name: true, avatar: true } }
      }
    });

    return NextResponse.json(task);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to update task' }, { status: 500 });
  }
}
