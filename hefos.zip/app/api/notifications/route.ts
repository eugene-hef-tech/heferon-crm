import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function GET() {
  try {
    const user = getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const notifications = await prisma.notification.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json(notifications);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to fetch notifications' }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const user = getCurrentUser();
    const body = await request.json();
    const { id, isRead } = body;

    const notification = await prisma.notification.update({
      where: { id, userId: user.id },
      data: { isRead }
    });
    return NextResponse.json(notification);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to update notification' }, { status: 500 });
  }
}
