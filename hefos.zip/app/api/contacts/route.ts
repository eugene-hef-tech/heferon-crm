import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const contacts = await prisma.contact.findMany({
      include: {
        company: true,
      },
      orderBy: {
        createdAt: 'desc'
      }
    });
    return NextResponse.json(contacts);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to fetch contacts' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { firstName, lastName, email, phone, companyId, market, leadSource, assignedToId } = body;
    
    if (!firstName || !lastName || !email || !market || !leadSource) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    const newContact = await prisma.contact.create({
      data: {
        firstName,
        lastName,
        email,
        phone,
        companyId,
        market,
        leadSource,
        assignedToId
      },
      include: {
        company: true
      }
    });

    return NextResponse.json(newContact);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to create contact' }, { status: 500 });
  }
}
