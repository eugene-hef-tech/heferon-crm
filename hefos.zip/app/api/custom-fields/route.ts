import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const entityType = searchParams.get('entityType');

  try {
    const customFields = await prisma.customFieldDefinition.findMany({
      where: entityType ? { entityType } : undefined,
      orderBy: { createdAt: 'asc' }
    });
    return NextResponse.json(customFields);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to fetch custom fields' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { entityType, name, type, options } = body;

    const customField = await prisma.customFieldDefinition.create({
      data: {
        entityType,
        name,
        type,
        options: options ? JSON.stringify(options) : null
      }
    });

    return NextResponse.json(customField);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to create custom field' }, { status: 500 });
  }
}
