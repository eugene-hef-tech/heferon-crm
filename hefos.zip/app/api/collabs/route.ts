import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const collabs = await prisma.collab.findMany({
      include: {
        members: { include: { user: { select: { name: true, avatar: true } } } },
        _count: { select: { tasks: true } }
      },
      orderBy: { createdAt: 'desc' }
    });
    return NextResponse.json(collabs);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to fetch collabs' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, description, userId } = body;
    
    if (!name || !userId) {
      return NextResponse.json({ error: 'Missing name or userId' }, { status: 400 });
    }

    const collab = await prisma.collab.create({
      data: {
        name,
        description,
        members: {
          create: {
            userId,
            role: 'OWNER'
          }
        }
      },
      include: {
        members: { include: { user: { select: { name: true, avatar: true } } } },
        _count: { select: { tasks: true } }
      }
    });

    return NextResponse.json(collab);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to create collab' }, { status: 500 });
  }
}
