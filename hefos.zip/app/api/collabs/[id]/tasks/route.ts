import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const params = await context.params;
    const body = await request.json();
    const { title, description, dueDate, assigneeId, creatorId } = body;
    
    if (!title || !creatorId) {
      return NextResponse.json({ error: 'Missing title or creatorId' }, { status: 400 });
    }

    const task = await prisma.task.create({
      data: {
        title,
        description,
        dueDate,
        collabId: params.id,
        creatorId,
        assigneeId
      },
      include: {
        assignee: { select: { name: true, avatar: true } },
        creator: { select: { name: true, avatar: true } }
      }
    });

    return NextResponse.json(task);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to create task' }, { status: 500 });
  }
}
