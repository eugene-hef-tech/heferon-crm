import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const companies = await prisma.company.findMany({
      include: {
        contacts: true,
        deals: true,
      },
      orderBy: {
        name: 'asc'
      }
    });
    return NextResponse.json(companies);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to fetch companies' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, industry, size, market, website, currency, assignedToId } = body;
    
    if (!name || !market || !currency) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    const newCompany = await prisma.company.create({
      data: {
        name,
        industry,
        size,
        market,
        website,
        currency,
        assignedToId
      },
      include: {
        contacts: true,
        deals: true
      }
    });

    return NextResponse.json(newCompany);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to create company' }, { status: 500 });
  }
}
