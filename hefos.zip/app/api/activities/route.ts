import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const activities = await prisma.activity.findMany({
      include: {
        deal: true,
        contact: true,
        company: true,
      },
      orderBy: {
        createdAt: 'desc'
      },
      take: 50
    });
    return NextResponse.json(activities);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to fetch activities' }, { status: 500 });
  }
}
