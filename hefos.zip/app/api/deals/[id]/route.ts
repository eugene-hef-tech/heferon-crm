import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { sendEmail } from '@/lib/email';

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const body = await request.json();
    
    const updateData: any = {};
    if (body.stage !== undefined) updateData.stage = body.stage;
    if (body.notes !== undefined) updateData.notes = body.notes;

    const deal = await prisma.deal.update({
      where: { id },
      data: updateData,
      include: {
        company: true,
        contact: true,
        assignedTo: true,
        activities: {
          orderBy: { createdAt: 'desc' }
        }
      }
    });
    
    // Log activity if stage changed
    if (body.stage) {
      await prisma.activity.create({
        data: {
          type: 'NOTE',
          direction: 'OUTBOUND',
          subject: `Deal moved to ${body.stage}`,
          dealId: id,
        }
      });

      // Check for stage automations
      const automation = await prisma.stageAutomation.findUnique({
        where: { stage: body.stage }
      });

      if (automation) {
        if (automation.createActivity && automation.activitySubject) {
          await prisma.activity.create({
            data: {
              type: automation.activityType || 'TASK',
              direction: 'OUTBOUND',
              subject: automation.activitySubject,
              dealId: id,
            }
          });
        }

        if (automation.sendNotification && deal.assignedToId) {
          await prisma.notification.create({
            data: {
              userId: deal.assignedToId,
              type: 'DEAL_STAGE_CHANGE',
              title: 'Automated Stage Notification',
              body: automation.notificationMessage || `Deal "${deal.title}" moved to ${body.stage.replace('_', ' ')}`,
              dealId: id
            }
          });
        }
      } else if (deal.assignedToId) {
        // Default notification if no automation is configured
        await prisma.notification.create({
          data: {
            userId: deal.assignedToId,
            type: 'DEAL_STAGE_CHANGE',
            title: 'Deal Stage Updated',
            body: `Deal "${deal.title}" moved to ${body.stage.replace('_', ' ')}`,
            dealId: id
          }
        });
      }

      // Send email to stakeholders (assigned user and main contact if attached)
      const stakeholders: string[] = [];
      if (deal.assignedTo?.email) stakeholders.push(deal.assignedTo.email);
      if (deal.contact?.email) stakeholders.push(deal.contact.email);

      if (stakeholders.length > 0) {
        const mailBody = `Hello,

The deal "${deal.title}" has been moved to a new stage: ${body.stage.replace('_', ' ')}.

Deal Value: ${deal.currency} ${deal.value}
${deal.company?.name ? `Company: ${deal.company.name}` : ''}
${deal.contact?.firstName ? `Contact: ${deal.contact.firstName} ${deal.contact.lastName || ''}` : ''}

Log in to the CRM to view the updated deal details.

Best,
HefOS CRM System`;

        await sendEmail({
          to: stakeholders,
          subject: `Deal Update: ${deal.title} moved to ${body.stage.replace('_', ' ')}`,
          body: mailBody
        });
      }
    }

    return NextResponse.json(deal);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to update deal' }, { status: 500 });
  }
}
