import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const deals = await prisma.deal.findMany({
      include: {
        company: true,
        contact: true,
        assignedTo: true,
        activities: {
          orderBy: { createdAt: 'desc' }
        }
      },
      orderBy: {
        updatedAt: 'desc'
      }
    });
    return NextResponse.json(deals);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to fetch deals' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { title, stage, market, currency, value, dealType, companyName, contactFirstName, contactLastName, contactEmail } = body;

    const company = await prisma.company.create({
      data: {
        name: companyName,
        market,
        currency
      }
    });

    const contact = await prisma.contact.create({
      data: {
        firstName: contactFirstName,
        lastName: contactLastName,
        email: contactEmail,
        market,
        leadSource: 'INBOUND',
        companyId: company.id
      }
    });

    const deal = await prisma.deal.create({
      data: {
        title,
        stage,
        market,
        currency,
        value,
        dealType,
        source: 'INBOUND',
        companyId: company.id,
        contactId: contact.id,
        lastActivityAt: new Date()
      },
      include: {
        company: true,
        contact: true,
        assignedTo: true,
        activities: true
      }
    });

    return NextResponse.json(deal);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to create deal' }, { status: 500 });
  }
}
