'use client';

import { useState, useEffect } from 'react';

const DEAL_STAGES = [
  'LEAD',
  'DISCOVERY',
  'DIAGNOSTIC',
  'PROPOSAL',
  'NEGOTIATION',
  'CLOSED_WON',
  'CLOSED_LOST'
];

export default function AutomationsPage() {
  const [automations, setAutomations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchAutomations();
  }, []);

  const fetchAutomations = async () => {
    try {
      const res = await fetch('/api/automations');
      const data = await res.json();
      setAutomations(data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (stage: string, data: any) => {
    setSaving(true);
    try {
      const res = await fetch('/api/automations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stage, ...data })
      });
      if (res.ok) {
        await fetchAutomations();
      }
    } catch (error) {
      console.error(error);
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="p-8 text-[zinc-400]">Loading automations...</div>;

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold text-white mb-6">Deal Stage Automations</h1>
      <p className="text-[zinc-400] mb-8">Configure automatic actions that trigger when a deal moves to a specific stage.</p>

      <div className="space-y-6">
        {DEAL_STAGES.map(stage => {
          const automation = automations.find(a => a.stage === stage) || {
            createActivity: false,
            activityType: 'TASK',
            activitySubject: '',
            sendNotification: false,
            notificationMessage: ''
          };

          return (
            <div key={stage} className="bg-[#0A0A0A] border border-white/5 rounded-xl p-6">
              <h2 className="text-lg font-semibold text-white mb-4">{stage.replace('_', ' ')}</h2>
              
              <div className="space-y-4">
                {/* Activity Automation */}
                <div className="bg-white/5 rounded-lg p-4">
                  <label className="flex items-center gap-3 mb-4 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={automation.createActivity}
                      onChange={(e) => handleSave(stage, { ...automation, createActivity: e.target.checked })}
                      className="w-4 h-4 rounded border-gray-300 text-[white] focus:ring-[white]"
                    />
                    <span className="text-white font-medium">Create Follow-up Activity</span>
                  </label>
                  
                  {automation.createActivity && (
                    <div className="pl-7 space-y-3">
                      <div>
                        <label className="block text-xs text-[zinc-400] mb-1">Activity Type</label>
                        <select 
                          value={automation.activityType}
                          onChange={(e) => handleSave(stage, { ...automation, activityType: e.target.value })}
                          className="w-full bg-[#0A0A0A] border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-[white]"
                        >
                          <option value="TASK">Task</option>
                          <option value="EMAIL">Email</option>
                          <option value="CALL">Call</option>
                          <option value="MEETING">Meeting</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs text-[zinc-400] mb-1">Subject / Description</label>
                        <input 
                          type="text" 
                          value={automation.activitySubject || ''}
                          onChange={(e) => handleSave(stage, { ...automation, activitySubject: e.target.value })}
                          placeholder="e.g., Follow up on proposal"
                          className="w-full bg-[#0A0A0A] border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-[white]"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Notification Automation */}
                <div className="bg-white/5 rounded-lg p-4">
                  <label className="flex items-center gap-3 mb-4 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={automation.sendNotification}
                      onChange={(e) => handleSave(stage, { ...automation, sendNotification: e.target.checked })}
                      className="w-4 h-4 rounded border-gray-300 text-[white] focus:ring-[white]"
                    />
                    <span className="text-white font-medium">Send Notification to Assigned User</span>
                  </label>
                  
                  {automation.sendNotification && (
                    <div className="pl-7">
                      <label className="block text-xs text-[zinc-400] mb-1">Custom Message (Optional)</label>
                      <input 
                        type="text" 
                        value={automation.notificationMessage || ''}
                        onChange={(e) => handleSave(stage, { ...automation, notificationMessage: e.target.value })}
                        placeholder="Leave blank for default message"
                        className="w-full bg-[#0A0A0A] border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-[white]"
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
