'use client';

import { useState, useEffect } from 'react';
import { Plus, Trash2 } from 'lucide-react';

export default function CustomFieldsSettings() {
  const [fields, setFields] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    entityType: 'DEAL',
    name: '',
    type: 'TEXT',
    options: ''
  });

  useEffect(() => {
    fetchFields();
  }, []);

  const fetchFields = async () => {
    try {
      const res = await fetch('/api/custom-fields');
      const data = await res.json();
      setFields(data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const optionsArray = formData.type === 'DROPDOWN' ? formData.options.split(',').map(s => s.trim()) : null;
      const res = await fetch('/api/custom-fields', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          options: optionsArray
        })
      });
      if (res.ok) {
        fetchFields();
        setIsModalOpen(false);
        setFormData({ entityType: 'DEAL', name: '', type: 'TEXT', options: '' });
      }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Custom Fields Settings</h1>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="bg-[white] text-[#0A0A0A] px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-opacity-90 transition-colors text-sm font-medium"
        >
          <Plus size={16} />
          <span>New Custom Field</span>
        </button>
      </div>

      <div className="bg-[#0A0A0A] rounded-2xl border border-white/5 overflow-hidden">
        <table className="w-full text-left text-[13px] border-collapse">
          <thead>
            <tr className="border-b border-white/5">
              <th className="p-4 font-medium text-[zinc-400]">Entity</th>
              <th className="p-4 font-medium text-[zinc-400]">Field Name</th>
              <th className="p-4 font-medium text-[zinc-400]">Type</th>
              <th className="p-4 font-medium text-[zinc-400]">Options</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={4} className="p-4 text-center text-[zinc-400]">Loading...</td></tr>
            ) : fields.length === 0 ? (
              <tr><td colSpan={4} className="p-4 text-center text-[zinc-400]">No custom fields defined.</td></tr>
            ) : (
              fields.map(field => (
                <tr key={field.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                  <td className="p-4 text-white font-medium">{field.entityType}</td>
                  <td className="p-4 text-white">{field.name}</td>
                  <td className="p-4">
                    <span className="text-[10px] px-2 py-1 rounded bg-white/10 text-[zinc-400]">
                      {field.type}
                    </span>
                  </td>
                  <td className="p-4 text-[zinc-400]">
                    {field.type === 'DROPDOWN' && field.options ? JSON.parse(field.options).join(', ') : '-'}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setIsModalOpen(false)}>
          <div className="bg-[#0A0A0A] rounded-2xl w-full max-w-md p-6 border border-white/10 shadow-2xl" onClick={e => e.stopPropagation()}>
            <h2 className="text-xl font-bold text-white mb-6">New Custom Field</h2>
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-xs text-[zinc-400] mb-1">Entity Type</label>
                <select 
                  value={formData.entityType} 
                  onChange={e => setFormData({...formData, entityType: e.target.value})}
                  className="w-full bg-white/5 border border-white/10 rounded-lg p-2.5 text-white text-sm focus:outline-none focus:border-[white]"
                >
                  <option value="DEAL">Deal</option>
                  <option value="CONTACT">Contact</option>
                  <option value="COMPANY">Company</option>
                </select>
              </div>
              <div>
                <label className="block text-xs text-[zinc-400] mb-1">Field Name</label>
                <input 
                  required 
                  type="text" 
                  value={formData.name} 
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  className="w-full bg-white/5 border border-white/10 rounded-lg p-2.5 text-white text-sm focus:outline-none focus:border-[white]"
                />
              </div>
              <div>
                <label className="block text-xs text-[zinc-400] mb-1">Field Type</label>
                <select 
                  value={formData.type} 
                  onChange={e => setFormData({...formData, type: e.target.value})}
                  className="w-full bg-white/5 border border-white/10 rounded-lg p-2.5 text-white text-sm focus:outline-none focus:border-[white]"
                >
                  <option value="TEXT">Text</option>
                  <option value="NUMBER">Number</option>
                  <option value="DATE">Date</option>
                  <option value="DROPDOWN">Dropdown</option>
                </select>
              </div>
              {formData.type === 'DROPDOWN' && (
                <div>
                  <label className="block text-xs text-[zinc-400] mb-1">Options (comma separated)</label>
                  <input 
                    required 
                    type="text" 
                    value={formData.options} 
                    onChange={e => setFormData({...formData, options: e.target.value})}
                    placeholder="Option 1, Option 2, Option 3"
                    className="w-full bg-white/5 border border-white/10 rounded-lg p-2.5 text-white text-sm focus:outline-none focus:border-[white]"
                  />
                </div>
              )}
              <div className="pt-4 flex justify-end gap-3">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 rounded-lg text-sm font-semibold text-[zinc-400] hover:text-white transition-colors">Cancel</button>
                <button type="submit" className="bg-[white] text-[#0A0A0A] px-6 py-2 rounded-lg text-sm font-semibold hover:bg-opacity-90 transition-colors">Create Field</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
