import Link from 'next/link';
import { LayoutDashboard, Briefcase, Users, Building2, Activity, Bell, MessageSquare, Users2, Megaphone, Bot, HeadphonesIcon, Puzzle } from 'lucide-react';

export function Sidebar() {
  return (
    <div className="w-64 bg-[#0A0A0A] text-white h-screen flex flex-col fixed left-0 top-0 border-r border-white/5 overflow-y-auto custom-scrollbar">
      <div className="p-6 sticky top-0 bg-[#0A0A0A] z-10">
        <h1 className="text-2xl font-bold bg-gradient-to-r from-white to-zinc-500 bg-clip-text text-transparent tracking-tight">
          HefOS
        </h1>
      </div>
      <nav className="flex-1 px-4 space-y-6 mt-2 pb-6">
        
        {/* Collaboration Section */}
        <div>
          <div className="text-xs font-semibold text-zinc-500 uppercase tracking-widest mb-3 px-4">Collaboration</div>
          <div className="space-y-0.5">
            <Link href="/dashboard" className="flex items-center gap-3 px-4 py-2.5 rounded-lg hover:bg-[#141414] text-zinc-400 hover:text-white transition-all">
              <LayoutDashboard size={18} />
              <span className="font-medium text-sm">Dashboard</span>
            </Link>
            <Link href="/feed" className="flex items-center gap-3 px-4 py-2.5 rounded-lg hover:bg-[#141414] text-zinc-400 hover:text-white transition-all">
              <MessageSquare size={18} />
              <span className="font-medium text-sm">Feed</span>
            </Link>
            <Link href="/collabs" className="flex items-center gap-3 px-4 py-2.5 rounded-lg hover:bg-[#141414] text-zinc-400 hover:text-white transition-all">
              <Users2 size={18} />
              <span className="font-medium text-sm">Collabs</span>
            </Link>
          </div>
        </div>

        {/* CRM Section */}
        <div>
          <div className="text-xs font-semibold text-zinc-500 uppercase tracking-widest mb-3 px-4">CRM</div>
          <div className="space-y-0.5">
            <Link href="/deals" className="flex items-center gap-3 px-4 py-2.5 rounded-lg hover:bg-[#141414] text-zinc-400 hover:text-white transition-all">
              <Briefcase size={18} />
              <span className="font-medium text-sm">Deals</span>
            </Link>
            <Link href="/contacts" className="flex items-center gap-3 px-4 py-2.5 rounded-lg hover:bg-[#141414] text-zinc-400 hover:text-white transition-all">
              <Users size={18} />
              <span className="font-medium text-sm">Contacts</span>
            </Link>
            <Link href="/companies" className="flex items-center gap-3 px-4 py-2.5 rounded-lg hover:bg-[#141414] text-zinc-400 hover:text-white transition-all">
              <Building2 size={18} />
              <span className="font-medium text-sm">Companies</span>
            </Link>
            <Link href="/activities" className="flex items-center gap-3 px-4 py-2.5 rounded-lg hover:bg-[#141414] text-zinc-400 hover:text-white transition-all">
              <Activity size={18} />
              <span className="font-medium text-sm">Activities</span>
            </Link>
          </div>
        </div>

        {/* Tools Section */}
        <div>
          <div className="text-xs font-semibold text-zinc-500 uppercase tracking-widest mb-3 px-4">Tools</div>
          <div className="space-y-0.5">
            <Link href="/marketing" className="flex items-center gap-3 px-4 py-2.5 rounded-lg hover:bg-[#141414] text-zinc-400 hover:text-white transition-all">
              <Megaphone size={18} />
              <span className="font-medium text-sm">Marketing</span>
            </Link>
            <Link href="/automation" className="flex items-center gap-3 px-4 py-2.5 rounded-lg hover:bg-[#141414] text-zinc-400 hover:text-white transition-all">
              <Bot size={18} />
              <span className="font-medium text-sm">Automation (RPA)</span>
            </Link>
            <Link href="/contact-center" className="flex items-center gap-3 px-4 py-2.5 rounded-lg hover:bg-[#141414] text-zinc-400 hover:text-white transition-all">
              <HeadphonesIcon size={18} />
              <span className="font-medium text-sm">Contact Center</span>
            </Link>
            <Link href="/integrations" className="flex items-center gap-3 px-4 py-2.5 rounded-lg hover:bg-[#141414] text-zinc-400 hover:text-white transition-all">
              <Puzzle size={18} />
              <span className="font-medium text-sm">Integrations</span>
            </Link>
            <Link href="/settings/custom-fields" className="flex items-center gap-3 px-4 py-2.5 rounded-lg hover:bg-[#141414] text-zinc-400 hover:text-white transition-all">
              <Building2 size={18} />
              <span className="font-medium text-sm">Custom Fields</span>
            </Link>
            <Link href="/settings/automations" className="flex items-center gap-3 px-4 py-2.5 rounded-lg hover:bg-[#141414] text-zinc-400 hover:text-white transition-all">
              <Bot size={18} />
              <span className="font-medium text-sm">Deal Automations</span>
            </Link>
          </div>
        </div>

      </nav>
      <div className="p-4 border-t border-white/5 sticky bottom-0 bg-[#0A0A0A]">
        <Link href="/notifications" className="flex items-center gap-3 px-4 py-3 w-full rounded-lg hover:bg-[#141414] text-zinc-400 hover:text-white transition-all">
          <Bell size={18} />
          <span className="font-medium text-sm">Notifications</span>
        </Link>
      </div>
    </div>
  );
}
