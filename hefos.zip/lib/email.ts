export interface EmailOptions {
  to: string | string[];
  subject: string;
  body: string;
}

/**
 * Mocks sending an email by logging to the console.
 * In a real application, you would integrate SendGrid, Postmark, AWS SES, etc.
 */
export async function sendEmail(options: EmailOptions) {
  const recipients = Array.isArray(options.to) ? options.to.join(', ') : options.to;
  
  if (!recipients) {
    console.log('📬 Attempted to send email, but no recipients were provided.');
    return;
  }

  console.log('\n======================================================');
  console.log('📨 SENDING EMAIL (STUB)');
  console.log('======================================================');
  console.log(`To:      ${recipients}`);
  console.log(`Subject: ${options.subject}`);
  console.log('------------------------------------------------------');
  console.log(options.body);
  console.log('======================================================\n');
  
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 500));
}
