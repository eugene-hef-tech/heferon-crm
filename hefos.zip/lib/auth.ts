export const getCurrentUser = () => {
  // Mock user for now. In a real app, this would come from a session/token.
  return {
    id: 'user-1',
    name: 'Eugene Hefer',
    email: 'eugene@heferon.tech',
    role: 'ADMIN', // ADMIN, SALES_MANAGER, SALES_REP, READ_ONLY
  };
};

export const hasPermission = (userRole: string, requiredRole: string) => {
  const roles = ['READ_ONLY', 'SALES_REP', 'SALES_MANAGER', 'ADMIN'];
  const userRoleIndex = roles.indexOf(userRole);
  const requiredRoleIndex = roles.indexOf(requiredRole);
  
  return userRoleIndex >= requiredRoleIndex;
};
